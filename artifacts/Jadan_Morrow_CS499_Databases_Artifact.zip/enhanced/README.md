# Grazioso Salvare Animal Rescue Dashboard

Jadan Morrow — CS 499 Milestone Four: Databases, September 29, 2026.

The enhanced April 19, 2026 CS 340 dashboard now uses bounded server-side pages, full-category breed summaries, and a projected cursor for nearest-candidate ranking. This is a local educational application. All included records are fictional; the original shelter dataset was unavailable.

## Quick start: no database required

Requires Python 3.12. From this enhanced directory:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m rescue_dashboard.app
```

Open http://127.0.0.1:8050. Stop with Ctrl+C. On macOS/Linux use python3.12 and .venv/bin/python. The default sample mode uses 14 intentionally varied fictional records, including invalid or missing coordinates. These are distinct from the validated 156-record database fixture. Internet access is required for dependency installation and map tiles.

## Database setup

Use an isolated MongoDB 8.0 test instance with authentication, bound to localhost. Verified locally with MongoDB 8.0.28 on port 27018. Configure an administrator privately using MongoDB's installation guidance. Do not use production data for the integration tests or benchmarks.

1. Set MONGODB_DATABASE=cs499_module5. Set MONGODB_ADMIN_URI, READER_PASSWORD and MAINTENANCE_PASSWORD privately in the environment. Run `python -m tools.provision_roles`. It creates cs499_reader (read) and cs499_maintenance (readWrite and dbAdmin), scoped to this database; existing passwords are unchanged. Clear administrator/password variables afterward.
2. Set MONGODB_SETUP_URI privately to the maintenance URI with authSource=cs499_module5. Preview: `python -m tools.database_setup data/database_fixture.json --database cs499_module5`. Expected: 156 accepted, none rejected. Preview does not connect or write. Review rejection reports before proceeding.
3. Apply: `python -m tools.database_setup data/database_fixture.json --database cs499_module5 --apply`. This refuses existing collections and refuses imports containing rejected rows. It creates the strict schema and imports the records. Do not point it at an existing dataset.
4. Run `python -m tools.install_indexes` with MONGODB_DATABASE=cs499_module5 and optionally MONGODB_COLLECTION=animals. It adds the measured page_order candidate and retains _id. Clear MONGODB_SETUP_URI afterward.
5. Launch with RESCUE_DATA_SOURCE=mongo, MONGODB_DATABASE=cs499_module5, MONGODB_COLLECTION=animals, and MONGODB_URI privately set to the reader URI. Run `python -m rescue_dashboard.app`. RESCUE_PORT defaults to 8050. The app binds to 127.0.0.1; debug is off by default. The .env.example file is documentation, not an automatically loaded configuration file.

Never pass maintenance credentials to the running dashboard. The existing workstation uses equivalent cs499_m5_reader and cs499_m5_maintenance accounts. No credentials are included here. The public portfolio is a static site and does not run this Python application.

## Behavior and deliberate trade-offs

Choose a category and 10, 25, or 50 rows per page. Next/Previous uses the first/last permanent _id boundary; changing category, page size or refreshing resets the page and selection. Queries project only dashboard fields, fetch one look-ahead row, and use a fixed _id order. Arbitrary browser text filtering and sorting were removed so a partial page cannot look like the full result set. Cursor and size validation happens before querying; users cannot supply query operators.

The breed chart summarizes the entire selected category in MongoDB, independently of the displayed page. The selected-animal map uses the current page. Missing coordinates stay missing. Find nearest reads all matching records through a projected cursor with batches of 100 and retains the existing bounded heap (k=1–100). Its output is ordered by unrounded Haversine distance and permanent ID. Distances are estimates, not driving routes or judgments of animal suitability. A cursor failure clears the result rather than presenting a partial ranking.

Paging and aggregation are separate reads, not a snapshot. Concurrent edits may change counts or page contents; refresh restarts traversal. The page is bounded, while summary memory depends on distinct breeds and ranking still scans all matches. String and ObjectId IDs are supported in separate, consistently typed collections. See docs/DATA_DICTIONARY.md. The old find method is retained only as a regression and benchmark reference; the dashboard uses page, summary, and iter_find.

## Verification

`python -m pytest -q` runs the suite. Without private database settings, 27 live cases skip and 133 other cases run. The recorded configured run passed all 160 tests with zero skips; 30 Dash DataTable deprecation warnings remain. Future major Dash upgrades need a table migration review.

To reproduce the 19 new live cases, use the exact cs499_module5 fixture above and set CS499_DATABASE_READER_URI to its reader URI plus MONGODB_SETUP_URI to its maintenance URI. Tests create objectid_fixture and optional_fixture and attempt rejected writes/schema changes; use only the isolated course database. Keep empty_fixture absent or empty. Eight inherited cases additionally require the original 14-record aac fixture: use tools/seed_mongo.py with a separate aac setup account on an empty collection, then set CS499_TEST_MONGODB_URI to an aac-scoped reader URI. Its unauthenticated probe expects local port 27018. These two fixture environments are separate.

Run `python benchmark_database.py` with the Module Five maintenance URI for the 10,000-record database comparison. It creates benchmark_v1 and 18 write-test collections; existing collection names cause refusal. For a later run, set CS499_BENCHMARK_RUN to a fresh suffix. The report file is replaced with the new measurements. Run `python benchmark_ranking.py` for the earlier ranking-only benchmark.

## Evidence

- docs/VALIDATION.md and test_results.txt: current test and browser evidence.
- docs/DATABASE_BENCHMARKS.md and database_benchmark.json: all query, payload, memory and write measurements with limits.
- docs/MODULE_FIVE_DECISIONS.md: review findings, decisions and outcome evidence.
- docs/BENCHMARKS.md and DESIGN_DECISIONS.md: historical Module Four algorithm evidence; MODULE_THREE and MODULE_FOUR named logs retain earlier results.
- ../original: original code with documented credential redactions.

MongoDB references: https://www.mongodb.com/docs/v8.0/reference/method/cursor.skip/ ; https://www.mongodb.com/docs/v8.0/reference/explain-results/ ; https://www.mongodb.com/docs/manual/reference/built-in-roles/

## Final portfolio handoff
October 8, 2026: the database milestone received 40/40. The final source implementation is unchanged. docs/REVIEW_AND_HANDOFF.md responds to the request for stronger collaboration evidence through a proposed review workflow and acceptance checks. Historical milestone reports retain their dates and scope.
