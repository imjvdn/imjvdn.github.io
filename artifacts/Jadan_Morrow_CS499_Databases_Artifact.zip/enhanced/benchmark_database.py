"""Controlled local MongoDB query, storage, import and streaming measurements.
Uses a NEW, isolated benchmark collection in the explicitly named test database.
"""
import json,os,time,statistics,tracemalloc,platform
from pathlib import Path
from pymongo import MongoClient
from rescue_dashboard.domain import Category,rescue_query
from rescue_dashboard.query import PROJECTION
from rescue_dashboard.repository import MongoRepository
from rescue_dashboard.ranking import nearest_heap
from tools.database_setup import create_collection
ROOT=Path(__file__).parent
INDEXES={'filter_range':[('animal_type',1),('sex_upon_outcome',1),('breed',1),('age_upon_outcome_in_weeks',1)],
         'page_order':[('animal_type',1),('sex_upon_outcome',1),('_id',1),('breed',1),('age_upon_outcome_in_weeks',1)]}

def measure(fn):
 fn();samples=[]
 for _ in range(5):
  start=time.perf_counter();fn();samples.append((time.perf_counter()-start)*1000)
 return {'samples_ms':samples,'median_ms':statistics.median(samples)}

def explain(db, collection, query, hint):
 plan=db.command('explain',{'find':collection.name,'filter':query,'projection':PROJECTION,'sort':{'_id':1},'limit':51,'hint':hint},verbosity='executionStats')
 stats=plan['executionStats']
 return {k:stats[k] for k in ('nReturned','totalDocsExamined','totalKeysExamined','executionTimeMillis')}

def main():
 uri=os.environ['MONGODB_SETUP_URI'];run=os.environ.get('CS499_BENCHMARK_RUN','v1')
 with MongoClient(uri) as client:
  db=client['cs499_module5'];name='benchmark_'+run
  base=json.loads((ROOT/'data/database_fixture.json').read_text())
  records=[dict(base[i%len(base)],_id=f'b-{i:06}') for i in range(10000)]
  c=create_collection(db,name,records)
  before=db.command('collStats',name)['totalIndexSize']
  builds={}
  for index,keys in INDEXES.items():
   start=time.perf_counter();c.create_index(keys,name=index);builds[index]=(time.perf_counter()-start)*1000
  results=[]
  for category in Category:
   for boundary in [None,'b-007000']:
    query=rescue_query(category)
    if boundary:query['_id']={'$gt':boundary}
    for hint in ['_id_',*INDEXES]:
     def fetch():return list(c.find(query,PROJECTION).sort('_id',1).limit(51).hint(hint))
     results.append({'category':category.value,'boundary':boundary,'index':hint,**measure(fetch),**explain(db,c,query,hint)})
  # Model a deep page and compare skip to a keyset with the same last-seen ID.
  def skip():return list(c.find({},PROJECTION).sort('_id',1).skip(7001).limit(50))
  def keyset():return list(c.find({'_id':{'$gt':'b-007000'}},PROJECTION).sort('_id',1).limit(50))
  assert [d['_id'] for d in skip()]==[d['_id'] for d in keyset()]
  deep={'skip':measure(skip),'keyset':measure(keyset)}
  repo=MongoRepository(c)
  def materialized():return nearest_heap(repo.find(Category.RESET),0,0,10)
  def streamed():return nearest_heap(repo.iter_find(Category.RESET),0,0,10)
  assert materialized().candidates==streamed().candidates
  memory={}
  for label,fn in [('materialized',materialized),('streamed',streamed)]:
   result=measure(fn);peaks=[]
   for _ in range(5):
    tracemalloc.start();fn();peaks.append(tracemalloc.get_traced_memory()[1]);tracemalloc.stop()
   memory[label]={**result,'peak_bytes':peaks,'median_peak_bytes':statistics.median(peaks)}
  all_rows=[a.to_row() for a in repo.find(Category.RESET)]
  page=repo.page(Category.RESET,50)
  payload={'full_rows_bytes':len(json.dumps(all_rows).encode()),'page_rows_bytes':len(json.dumps([a.to_row() for a in page.animals]).encode()),'page_rows':len(page.animals)}
  writes=[]
  for label in ['baseline',*INDEXES]:
   trials=[]
   for i in range(6):
    wc=create_collection(db,f'write_{run}_{label}_{i}',[])
    if label in INDEXES:wc.create_index(INDEXES[label],name=label)
    start=time.perf_counter();wc.insert_many(records[:2000]);elapsed=(time.perf_counter()-start)*1000
    if i:trials.append(elapsed)
   writes.append({'index':label,'records':2000,'samples_ms':trials,'median_ms':statistics.median(trials)})
  report={'fixture_records':len(records),'seed':'deterministic cycling of 156 validated fictional records',
    'environment':{'python':platform.python_version(),'platform':platform.platform(),'mongodb':client.server_info()['version']},
    'warmups':1,'repetitions':5,'query_results':results,'deep_page':deep,'streaming':memory,'payload':payload,
    'index_build_ms':builds,'baseline_index_bytes':before,'index_sizes':db.command('collStats',name)['indexSizes'],'write_results':writes}
  (ROOT/'docs/database_benchmark.json').write_text(json.dumps(report,indent=2))
  print(json.dumps({k:report[k] for k in ['deep_page','streaming','payload','index_sizes','write_results']},indent=2))
if __name__=='__main__':main()
