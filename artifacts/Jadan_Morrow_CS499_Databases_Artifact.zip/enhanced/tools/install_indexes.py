"""Install the measured pagination candidate; retain the automatic _id index.
The query planner chooses a plan; benchmarks use hints only to compare alternatives.
"""
import os
from pymongo import MongoClient
PAGE_INDEX=[('animal_type',1),('sex_upon_outcome',1),('_id',1),('breed',1),('age_upon_outcome_in_weeks',1)]
def main():
    with MongoClient(os.environ['MONGODB_SETUP_URI']) as client:
        c=client[os.environ['MONGODB_DATABASE']][os.environ.get('MONGODB_COLLECTION','animals')]
        c.create_index(PAGE_INDEX,name='page_order')
        print('Pagination candidate installed. The _id index remains available.')
if __name__=='__main__':main()
