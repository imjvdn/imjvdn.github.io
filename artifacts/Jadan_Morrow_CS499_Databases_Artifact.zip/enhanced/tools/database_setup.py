"""Preview imports by default; apply only to a NEW collection in an explicit database.
Setup URI is private environment configuration, never a command-line argument.
"""
import argparse, json, os, math
from pathlib import Path
from pymongo import MongoClient
from bson import ObjectId

TEXT_FIELDS = ('animal_id','name','animal_type','breed','sex_upon_outcome')

def schema(id_type='string'):
    if id_type not in ('string','objectId'): raise ValueError('Unsupported ID type.')
    fields = {'_id': {'bsonType':id_type}}
    if id_type == 'string': fields['_id'].update(minLength=1,maxLength=200,pattern=r'^[^\x00]+$')
    fields.update({key:{'bsonType':'string','minLength':1,'maxLength':200} for key in TEXT_FIELDS})
    fields['age_upon_outcome_in_weeks']={'bsonType':['int','long','double','decimal'],'minimum':0,'maximum':10000}
    for key,low,high in [('location_lat',-90,90),('location_long',-180,180)]:
        fields[key]={'bsonType':['int','long','double','decimal','null'],'minimum':low,'maximum':high}
    return {'$jsonSchema':{'bsonType':'object','required':['_id',*TEXT_FIELDS,'age_upon_outcome_in_weeks'],
                          'properties':fields}}

def validator(id_type='string'):
    value=schema(id_type)
    return value

def validate_record(doc, id_type='string'):
    if not isinstance(doc,dict): return 'Record must be an object.'
    key=doc.get('_id')
    if id_type=='string':
        if not isinstance(key,str) or not key.strip() or len(key)>200 or '\x00' in key: return 'Invalid string _id.'
    elif not isinstance(key,ObjectId): return 'ObjectId required.'
    for field in TEXT_FIELDS:
        v=doc.get(field)
        if not isinstance(v,str) or not v.strip() or len(v)>200 or v!=v.strip(): return 'Invalid '+field+'.'
    for field,lo,hi,optional in [('age_upon_outcome_in_weeks',0,10000,False),
                ('location_lat',-90,90,True),('location_long',-180,180,True)]:
        v=doc.get(field)
        if optional and v is None: continue
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not lo<=v<=hi:
            return 'Invalid '+field+'.'
    return None

def preview(records):
    accepted=[]; rejected=[]; seen=set()
    for row,doc in enumerate(records,1):
        reason=validate_record(doc)
        if reason is None and doc['_id'] in seen: reason='Duplicate _id in import.'
        if reason: rejected.append({'row':row,'reason':reason})
        else: accepted.append(doc);seen.add(doc['_id'])
    return accepted,rejected

def create_collection(db, name, records, id_type='string'):
    if name in db.list_collection_names(): raise ValueError('Collection already exists; no changes made.')
    if any(validate_record(doc,id_type) for doc in records): raise ValueError('Preview contains malformed records.')
    collection=db.create_collection(name, validator=validator(id_type),validationLevel='strict',validationAction='error')
    if records: collection.insert_many(records)
    return collection

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path);parser.add_argument('--database',required=True)
    parser.add_argument('--collection',default='animals');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    records=json.loads(args.input.read_text(encoding='utf-8'))
    if not isinstance(records,list): raise SystemExit('Input must be a JSON array.')
    accepted,rejected=preview(records)
    print(json.dumps({'accepted':len(accepted),'rejected':rejected},indent=2))
    if not args.apply: return
    if rejected: raise SystemExit('Apply refused: fix rejected rows and preview again.')
    uri=os.environ.get('MONGODB_SETUP_URI')
    if not uri: raise SystemExit('Set MONGODB_SETUP_URI privately.')
    with MongoClient(uri,serverSelectionTimeoutMS=5000) as client:
        create_collection(client[args.database],args.collection,accepted)
    print('Validated collection created. No existing collection was replaced.')

if __name__=='__main__': main()
