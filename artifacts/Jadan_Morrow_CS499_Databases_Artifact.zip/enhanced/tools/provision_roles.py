"""Create scoped accounts once; run with an administrator, never the dashboard URI."""
import os
from pymongo import MongoClient

def main():
    database=os.environ['MONGODB_DATABASE']
    if database in ('admin','local','config'): raise SystemExit('Choose an application database.')
    with MongoClient(os.environ['MONGODB_ADMIN_URI']) as client:
        db=client[database]
        for user,key,roles in [('cs499_reader','READER_PASSWORD',['read']),
                               ('cs499_maintenance','MAINTENANCE_PASSWORD',['readWrite','dbAdmin'])]:
            if not db.command('usersInfo',user)['users']:
                db.command('createUser',user,pwd=os.environ[key],roles=[{'role':r,'db':database} for r in roles])
        print('Scoped accounts are ready. Existing passwords were not changed.')
if __name__=='__main__':main()
