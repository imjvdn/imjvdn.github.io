from dataclasses import replace
import math
import random
from unittest.mock import MagicMock
import pytest
from rescue_dashboard.domain import Animal, ValidationError
from rescue_dashboard.ranking import nearest_heap, nearest_full_sort, haversine_km, validate_request
from rescue_dashboard.repository import InMemoryRepository
from rescue_dashboard.app import create_app

def animal(key, lat=0, lon=0):
    return Animal(str(key),'A','Example','Dog','Labrador Retriever Mix','Intact Female',26,lat,lon)

@pytest.mark.parametrize('first,second,expected', [((0,0),(0,0),0),((0,0),(0,1),111.1950802),
    ((0,0),(0,180),20015.114442),((0,179),(0,-179),222.3901605),((90,0),(-90,0),20015.114442)])
def test_known_distances(first,second,expected):
    assert haversine_km(first,second) == pytest.approx(expected,abs=0.001)
    assert haversine_km(second,first) == pytest.approx(expected,abs=0.001)

@pytest.mark.parametrize('lat,lon,k', [(91,0,1),(-91,0,1),(0,181,1),(0,-181,1),
    (math.nan,0,1),(0,math.inf,1),(None,0,1),(True,0,1),(0,0,True),(0,0,0),
    (0,0,101),(0,0,1.5),(0,0,None),(0,0,math.inf),(0,0,{}),('bad',0,1)])
def test_invalid_requests(lat,lon,k):
    with pytest.raises(ValidationError): validate_request(lat,lon,k)

@pytest.mark.parametrize('k',[1,10,100])
def test_empty_and_more_requested_than_available(k):
    assert nearest_heap(iter([]),0,0,k).candidates == ()
    result=nearest_heap(iter([animal('one')]),0,0,k)
    assert len(result.candidates)==1 and result.peak_retained==1

def test_ties_use_id_and_do_not_depend_on_input_order():
    records=[animal(key) for key in ['z','b','a','c']]
    for seed in range(10):
        random.Random(seed).shuffle(records)
        result=nearest_heap(iter(records),0,0,2)
        assert [x.animal.record_id for x in result.candidates]==['a','b']

def test_invalid_locations_are_counted_and_zero_is_valid():
    records=[animal('ok'),animal('missing',None,0),animal('nan',math.nan,0),animal('range',0,181)]
    result=nearest_heap(iter(records),0,0,10)
    assert (result.examined,result.excluded)==(4,3)
    assert [x.animal.record_id for x in result.candidates]==['ok']

@pytest.mark.parametrize('seed',range(6))
@pytest.mark.parametrize('k',[1,10,100])
def test_heap_matches_full_sort_over_deterministic_records(seed,k):
    rng=random.Random(seed)
    records=[animal(f'{i:06}',rng.uniform(-90,90),rng.uniform(-180,180)) for i in range(300)]
    records.extend([animal('tie-a'),animal('tie-b'),animal('invalid',None,0)])
    actual=nearest_heap(iter(records),0,0,k)
    expected=nearest_full_sort(iter(records),0,0,k)
    assert actual.candidates == expected.candidates
    assert actual.excluded == expected.excluded == 1
    assert actual.peak_retained <= k

def test_stream_consumed_once_and_capacity_bounded():
    consumed=[]
    def stream():
        for i in range(1000):
            consumed.append(i)
            yield animal(str(i),0,i/1000)
    result=nearest_heap(stream(),0,0,10)
    assert len(consumed)==1000 and result.peak_retained==10

def test_invalid_request_does_not_access_repository():
    repo=MagicMock()
    app=create_app(repository=repo)
    rows,message=app.rescue_callbacks['rank']('Reset',91,0,10)
    assert not rows and 'latitude' in message
    repo.find.assert_not_called()

def test_shortlist_keeps_rescue_eligibility_and_explains_exclusions():
    records=[animal('near'),animal('invalid',None,0),replace(animal('cat'),animal_type='Cat')]
    app=create_app(repository=InMemoryRepository(records))
    rows,message=app.rescue_callbacks['rank']('Water Rescue',0,0,10)
    assert [r['id'] for r in rows]==['near']
    assert '2 eligible' in message and '1 excluded' in message

def test_shortlist_http_action_and_input_change_clear_results():
    app=create_app(repository=InMemoryRepository([animal('one')]))
    key=next(key for key in app.callback_map if 'shortlist.data' in key)
    client=app.server.test_client()
    payload={'output':key,'outputs':[{'id':'shortlist','property':'data'}, {'id':'rank-status','property':'children'}],
        'inputs':[{'id':id,'property':prop,'value':value} for id,prop,value in [
            ('rank','n_clicks',1),('category','value','Reset'),('retry','n_clicks',0),
            ('center-lat','value',0),('center-lon','value',0),('shortlist-k','value',10)]],
        'state':[],'changedPropIds':['rank.n_clicks']}
    response=client.post('/_dash-update-component',json=payload)
    assert response.status_code==200
    assert response.json['response']['shortlist']['data'][0]['id']=='one'
    payload['changedPropIds']=['center-lat.value']
    response=client.post('/_dash-update-component',json=payload)
    assert response.json['response']['shortlist']['data']==[]
