import json, os
from dataclasses import replace
from unittest.mock import MagicMock
from collections import Counter
import pytest
from pymongo import MongoClient
from pymongo.errors import OperationFailure
from bson import ObjectId
from rescue_dashboard.query import request, encode_id, decode_id
from rescue_dashboard.domain import Animal, Category, ValidationError
from rescue_dashboard.repository import InMemoryRepository, MongoRepository, RepositoryError
from rescue_dashboard.app import create_app
from rescue_dashboard.ranking import nearest_full_sort
from tools.database_setup import preview, validate_record, create_collection
from test_dashboard import record

@pytest.mark.parametrize('size',[0,51,-1,True,2.5,'10',None])
def test_reject_page_size(size):
    with pytest.raises(ValidationError): request('Reset',size)

@pytest.mark.parametrize('token',[{},'', 'x:id','o:bad','s:','s:'+'x'*201,'s:a\x00b'])
def test_reject_cursor(token):
    with pytest.raises(ValidationError): request('Reset',10,token)

@pytest.mark.parametrize('key',['record-1',ObjectId()])
def test_cursor_type_roundtrip(key): assert decode_id(encode_id(key)) == key

@pytest.mark.parametrize('category',[None,{'$where':'bad'},'bad'])
def test_category_rejected_before_queries(category):
    repo=MagicMock();app=create_app(repository=repo)
    assert app.rescue_callbacks['page'](category)[0] == []
    repo.page.assert_not_called();repo.summary.assert_not_called()

def test_paging_and_previous_and_full_summary():
    repo=InMemoryRepository([record(_id=f'{i:03}') for i in range(123)])
    seen=[];cursor=None
    while True:
        p=repo.page('Reset',50,cursor);seen.extend(a.record_id for a in p.animals)
        assert len(p.animals)<=50
        if not p.has_next:break
        cursor=p.last
    assert len(seen)==len(set(seen))==123
    previous=repo.page('Reset',50,p.first,'previous')
    assert [a.record_id for a in previous.animals]==seen[50:100]
    assert sum(repo.summary('Reset').values())==123

def test_stream_ranking_reaches_beyond_first_page():
    records=[replace(record(_id=f'{i:03}'),latitude=40,longitude=0) for i in range(70)]
    records[-1]=replace(records[-1],latitude=0,longitude=0)
    repo=InMemoryRepository(records);app=create_app(repository=repo)
    assert len(app.rescue_callbacks['page']('Reset',10)[0])==10
    rows,msg=app.rescue_callbacks['rank']('Reset',0,0,1)
    assert rows[0]['id']=='069' and '70 eligible' in msg

def test_page_chart_is_full_population_and_selection_clears():
    repo=InMemoryRepository([record(_id=str(i),breed='Poodle' if i>5 else 'Labrador Retriever Mix') for i in range(20)])
    app=create_app(repository=repo);value=app.rescue_callbacks['page']('Reset',5)
    assert value[2:4]==([],[])
    chart,_=app.rescue_callbacks['views'](value[0],[],value[0],value[-1])
    assert sum(chart.figure['data'][0]['values'])==20

def test_cursor_failure_during_ranking_discards_partial_result():
    repo=MagicMock()
    def stream(category):
        yield record()
        raise RepositoryError('SECRET')
    repo.iter_find=stream
    rows,msg=create_app(repository=repo).rescue_callbacks['rank']('Reset',0,0,5)
    assert not rows and 'Retry' in msg and 'SECRET' not in msg

def doc(**changes):
    result=record().to_row();result['_id']=result.pop('id');result.update(changes);return result

@pytest.mark.parametrize('changes',[{'_id':''},{'breed':3},{'name':'  '}, {'age_upon_outcome_in_weeks':-1},
 {'age_upon_outcome_in_weeks':True},{'location_lat':91},{'location_lon':0,'location_long':float('inf')},
 {'location_lat':float('nan')},{'animal_id':None}])
def test_import_reports_bad_rows(changes):
    accepted,rejected=preview([doc(),doc(**changes)])
    assert len(accepted)==1 and rejected[0]['row']==2

def test_import_missing_coordinates_and_duplicates():
    assert validate_record(doc(location_lat=None,location_long=None)) is None
    good,bad=preview([doc(),doc()]);assert len(good)==1 and 'Duplicate' in bad[0]['reason']

LIVE=bool(os.environ.get('CS499_DATABASE_READER_URI') and os.environ.get('MONGODB_SETUP_URI'))
@pytest.fixture
def live():
    if not LIVE:pytest.skip('Separate Module Five fixture database not configured.')
    reader=MongoClient(os.environ['CS499_DATABASE_READER_URI']);maintenance=MongoClient(os.environ['MONGODB_SETUP_URI'])
    db=maintenance['cs499_module5'];repo=MongoRepository(reader['cs499_module5']['animals'],reader)
    yield repo,db,reader
    reader.close();maintenance.close()

@pytest.mark.parametrize('category',list(Category))
def test_live_all_pages_summary_and_ranking(live,category):
    repo,db,_=live;oracle=InMemoryRepository([Animal.from_document(d) for d in db.animals.find({})])
    seen=[];cursor=None
    while True:
        page=repo.page(category,10,cursor);seen.extend(a.record_id for a in page.animals)
        assert len(page.animals)<=10
        if not page.has_next:break
        cursor=page.last
    assert seen==sorted(a.record_id for a in oracle.find(category))
    assert repo.summary(category)==dict(Counter(a.breed for a in oracle.find(category)))
    from rescue_dashboard.ranking import nearest_heap
    assert nearest_heap(repo.iter_find(category),0,0,10).candidates==nearest_full_sort(oracle.find(category),0,0,10).candidates
    if page.first and page.has_previous:
        prev=repo.page(category,10,page.first,'previous')
        assert prev.animals and prev.animals[-1].record_id < page.animals[0].record_id

@pytest.mark.parametrize('action',['insert','update','delete','index','schema','other_database'])
def test_live_reader_denials(live,action):
    repo,db,reader=live;c=reader['cs499_module5']['animals']
    calls={'insert':lambda:c.insert_one(doc(_id='permission-probe')),
      'update':lambda:c.update_one({'_id':'does-not-exist'},{'$set':{'name':'probe'}}),
      'delete':lambda:c.delete_one({'_id':'does-not-exist'}),
      'index':lambda:c.create_index('name'),
      'schema':lambda:reader['cs499_module5'].command({'collMod':'animals','validationLevel':'strict'}),
      'other_database':lambda:reader['aac']['animals'].find_one({})}
    with pytest.raises(OperationFailure) as err:calls[action]()
    assert err.value.code==13

@pytest.mark.parametrize('changes',[{'age_upon_outcome_in_weeks':-1},{'location_lat':91}, {'location_long':181},
 {'breed':42},{'_id':ObjectId()},{'location_lat':float('nan')}])
def test_live_schema_rejects_invalid_write(live,changes):
    _,db,_=live
    with pytest.raises(OperationFailure) as err:db.animals.insert_one(doc(_id='invalid-schema-probe',**{k:v for k,v in changes.items() if k!='_id'}) if '_id' not in changes else doc(**changes))
    assert err.value.code==121

def test_live_setup_refuses_existing_collection(live):
    _,db,_=live
    with pytest.raises(ValueError):create_collection(db,'animals',[])

def test_live_objectid_pages_and_empty_collection(live):
    repo,db,reader=live
    if 'objectid_fixture' not in db.list_collection_names():
        create_collection(db,'objectid_fixture',[doc(_id=ObjectId()) for _ in range(12)],'objectId')
    objects=MongoRepository(reader.cs499_module5.objectid_fixture)
    first=objects.page('Reset',5);second=objects.page('Reset',5,first.last)
    assert not set(a.record_id for a in first.animals)&set(a.record_id for a in second.animals)
    assert objects.page('Reset',5,second.first,'previous').animals==first.animals
    assert MongoRepository(reader.cs499_module5.empty_fixture).page('Reset').animals==()

def test_http_navigation_resets_after_category_or_size_change():
    app=create_app(repository=InMemoryRepository([record(_id=f'{i:03}') for i in range(35)]))
    client=app.server.test_client();key=next(k for k in app.callback_map if 'animals.data' in k)
    outputs=[{'id':i,'property':p} for i,p in [('animals','data'),('status','children'),('animals','selected_rows'),('animals','selected_row_ids'),('page-state','data'),('previous','disabled'),('next','disabled'),('breed-summary','data')]]
    def call(trigger,state=None,category='Reset',size=10):
        resp=client.post('/_dash-update-component',json={'output':key,'outputs':outputs,
          'inputs':[{'id':i,'property':p,'value':v} for i,p,v in [('category','value',category),('retry','n_clicks',0),('page-size','value',size),('next','n_clicks',1),('previous','n_clicks',1)]],
          'state':[{'id':'page-state','property':'data','value':state}],'changedPropIds':[trigger]})
        assert resp.status_code==200
        return resp.json['response']
    first=call('category.value');second=call('next.n_clicks',first['page-state']['data'])
    assert first['animals']['data'][0]['id']=='000' and second['animals']['data'][0]['id']=='010'
    previous=call('previous.n_clicks',second['page-state']['data'])
    assert previous['animals']['data']==first['animals']['data']
    changed=call('category.value',second['page-state']['data'],'Water Rescue')
    assert changed['animals']['data'][0]['id']=='000' and changed['animals']['selected_row_ids']==[]
    resized=call('page-size.value',second['page-state']['data'],size=25)
    assert len(resized['animals']['data'])==25 and resized['animals']['data'][0]['id']=='000'

def test_live_missing_optional_coordinates(live):
    _,db,_=live
    if 'optional_fixture' not in db.list_collection_names():
        data=doc(_id='optional');data.pop('location_lat');data.pop('location_long')
        create_collection(db,'optional_fixture',[data])
    assert Animal.from_document(db.optional_fixture.find_one({})).coordinates is None
