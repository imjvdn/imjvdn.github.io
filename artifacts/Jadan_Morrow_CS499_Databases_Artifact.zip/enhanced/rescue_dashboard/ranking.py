"""Nearest eligible records, with a bounded max-heap and full-sort reference.

Keys are (unrounded great-circle distance in km, permanent record ID).
Input records must have unique IDs, as enforced by the repository boundary.
"""
from dataclasses import dataclass
from math import radians, sin, cos, atan2, sqrt
import heapq
from .domain import Animal, ValidationError, finite_number

EARTH_RADIUS_KM = 6371.0088

def validate_request(latitude, longitude, k):
    lat, lon, count = map(finite_number, (latitude, longitude, k))
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise ValidationError('Enter a finite latitude from -90 to 90 and longitude from -180 to 180.')
    if count is None or not count.is_integer() or not 1 <= count <= 100:
        raise ValidationError('Enter a whole-number shortlist size from 1 to 100.')
    return (lat, lon), int(count)

def haversine_km(first, second):
    """Great-circle distance on a sphere; callers supply valid coordinates."""
    lat1, lon1 = map(radians, first)
    lat2, lon2 = map(radians, second)
    value = sin((lat2-lat1)/2)**2 + cos(lat1)*cos(lat2)*sin((lon2-lon1)/2)**2
    value = min(1.0, max(0.0, value))
    return 2 * EARTH_RADIUS_KM * atan2(sqrt(value), sqrt(1-value))

@dataclass(frozen=True)
class Candidate:
    animal: Animal
    distance_km: float

    @property
    def key(self):
        return self.distance_km, self.animal.record_id

    def to_row(self):
        return {**self.animal.to_row(), 'distance_km': round(self.distance_km, 3)}

@dataclass(frozen=True)
class RankingResult:
    candidates: tuple[Candidate, ...]
    examined: int
    excluded: int
    peak_retained: int

@dataclass
class _WorstFirst:
    candidate: Candidate

    def __lt__(self, other):
        # Reverse the COMPLETE key so even a distance tie has the worst ID at root.
        return self.candidate.key > other.candidate.key

def nearest_heap(animals, latitude, longitude, k):
    center, count = validate_request(latitude, longitude, k)
    heap = []
    examined = excluded = peak = 0
    for animal in animals:
        examined += 1
        location = animal.coordinates
        if location is None:
            excluded += 1
            continue
        candidate = Candidate(animal, haversine_km(center, location))
        if len(heap) < count:
            heapq.heappush(heap, _WorstFirst(candidate))
            peak = max(peak, len(heap))
        elif candidate.key < heap[0].candidate.key:
            heapq.heapreplace(heap, _WorstFirst(candidate))
    return RankingResult(tuple(sorted((entry.candidate for entry in heap), key=lambda c:c.key)),
                         examined, excluded, peak)

def nearest_full_sort(animals, latitude, longitude, k):
    """New correctness/reference baseline, not functionality in the original app."""
    center, count = validate_request(latitude, longitude, k)
    candidates = []
    examined = excluded = 0
    for animal in animals:
        examined += 1
        location = animal.coordinates
        if location is None:
            excluded += 1
        else:
            candidates.append(Candidate(animal, haversine_km(center, location)))
    candidates.sort(key=lambda c:c.key)
    return RankingResult(tuple(candidates[:count]), examined, excluded, len(candidates))
