"""Read-only repository interface and interchangeable data adapters."""
from typing import Protocol
import json
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from .domain import Animal, Category, ValidationError, eligible, rescue_query


class RepositoryError(RuntimeError):
    pass


class AnimalRepository(Protocol):
    def find(self, category: Category) -> list[Animal]: ...
    def page(self, category, size=10, cursor=None, direction="next"): ...
    def summary(self, category): ...
    def iter_find(self, category): ...
    def close(self) -> None: ...


def normalize(documents):
    animals = [Animal.from_document(doc) for doc in documents]
    ids = [animal.record_id for animal in animals]
    if len(set(ids)) != len(ids):
        raise ValidationError('Record IDs must be unique.')
    return animals


class _MemoryReference:
    def __init__(self, animals):
        self._animals = tuple(animals)

    @classmethod
    def from_file(cls, path):
        try:
            return cls(normalize(json.loads(path.read_text(encoding='utf-8'))))
        except (OSError, ValueError, TypeError, AttributeError):
            raise RepositoryError('Sample records could not be loaded.') from None

    def find(self, category):
        return [a for a in self._animals if eligible(a, category)]

    def close(self):
        pass


class _MongoReference:
    def __init__(self, collection, client=None):
        self._collection = collection
        self._client = client

    @classmethod
    def connect(cls, settings):
        try:
            client = MongoClient(settings.mongo_uri, serverSelectionTimeoutMS=2000,
                                 connectTimeoutMS=2000, socketTimeoutMS=2000)
            return cls(client[settings.database][settings.collection], client)
        except (PyMongoError, ValueError, TypeError):
            raise RepositoryError('Database configuration could not be used.') from None

    def find(self, category):
        # Milestone Two preserves full result loading. Server-side paging is future work.
        projection = {key: 1 for key in ('_id', 'animal_id', 'name', 'animal_type', 'breed',
                      'sex_upon_outcome', 'age_upon_outcome_in_weeks', 'location_lat', 'location_long')}
        try:
            with self._collection.find(rescue_query(category), projection) as cursor:
                return normalize(cursor)
        except (PyMongoError, ValidationError, TypeError, AttributeError):
            raise RepositoryError('Database records could not be loaded.') from None

    def close(self):
        if self._client is not None:
            self._client.close()


class _UnavailableReference:
    """Keeps the interface available when local sample configuration is invalid."""
    def find(self, category):
        raise RepositoryError('Data source unavailable.')

    def close(self):
        pass


# Keep find() as a legacy/reference API. The dashboard uses the bounded API below.
from collections import Counter
from .query import Page, PROJECTION, request, encode_id

class InMemoryRepository(_MemoryReference):
    def page(self, category, size=10, cursor=None, direction='next'):
        category, boundary = request(category, size, cursor, direction)
        records = sorted(self.find(category), key=lambda a:a.record_id)
        candidates = [a for a in records if boundary is None or
                      (a.record_id > boundary if direction == 'next' else a.record_id < boundary)]
        rows = candidates[:size] if direction == 'next' else candidates[-size:]
        return Page(tuple(rows), encode_id(rows[0].record_id) if rows else None,
                    encode_id(rows[-1].record_id) if rows else None,
                    bool(rows and any(a.record_id < rows[0].record_id for a in records)),
                    bool(rows and any(a.record_id > rows[-1].record_id for a in records)))

    def summary(self, category):
        return dict(sorted(Counter(a.breed for a in self.find(Category.parse(category))).items()))

    def iter_find(self, category):
        category = Category.parse(category)
        return (a for a in self._animals if eligible(a, category))

class MongoRepository(_MongoReference):
    def page(self, category, size=10, cursor=None, direction='next'):
        category, boundary = request(category, size, cursor, direction)
        query = rescue_query(category)
        if boundary is not None:
            query['_id'] = {'$gt' if direction == 'next' else '$lt': boundary}
        order = 1 if direction == 'next' else -1
        try:
            with self._collection.find(query, PROJECTION).sort('_id',order).limit(size+1).max_time_ms(5000) as cur:
                docs = list(cur)
            extra = len(docs) > size
            docs = docs[:size]
            if direction == 'previous': docs.reverse()
            rows = tuple(normalize(docs))
            return Page(rows, encode_id(docs[0]['_id']) if docs else None,
                        encode_id(docs[-1]['_id']) if docs else None,
                        (boundary is not None if direction == 'next' else extra),
                        (extra if direction == 'next' else boundary is not None))
        except (PyMongoError, ValidationError, TypeError, AttributeError):
            raise RepositoryError('Database page could not be loaded.') from None

    def summary(self, category):
        category = Category.parse(category)
        pipeline = [{'$match':rescue_query(category)},
                    {'$group':{'_id':'$breed','count':{'$sum':1}}}, {'$sort':{'_id':1}}]
        try:
            with self._collection.aggregate(pipeline, maxTimeMS=5000) as cur:
                return {str(row['_id']):row['count'] for row in cur}
        except (PyMongoError, TypeError, AttributeError):
            raise RepositoryError('Database summary could not be loaded.') from None

    def iter_find(self, category):
        category = Category.parse(category)
        # A single cursor holds at most a driver batch plus the ranking heap.
        # MongoDB enforces unique _id values. Schema setup requires one ID type.
        try:
            with self._collection.find(rescue_query(category), PROJECTION).batch_size(100).max_time_ms(5000) as cur:
                for doc in cur:
                    yield Animal.from_document(doc)
        except (PyMongoError, ValidationError, TypeError, AttributeError):
            raise RepositoryError('Database ranking records could not be loaded.') from None

class UnavailableRepository(_UnavailableReference):
    def page(self, *args, **kwargs): raise RepositoryError('Data source unavailable.')
    def summary(self, *args, **kwargs): raise RepositoryError('Data source unavailable.')
    def iter_find(self, *args, **kwargs): raise RepositoryError('Data source unavailable.')
