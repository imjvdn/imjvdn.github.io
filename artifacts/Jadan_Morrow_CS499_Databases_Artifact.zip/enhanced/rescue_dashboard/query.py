"""Validated keyset requests and bounded page values."""
from dataclasses import dataclass
from bson import ObjectId
from .domain import Category, ValidationError

FIELDS = ('_id','animal_id','name','animal_type','breed','sex_upon_outcome',
          'age_upon_outcome_in_weeks','location_lat','location_long')
PROJECTION = dict.fromkeys(FIELDS, 1)

@dataclass(frozen=True)
class Page:
    animals: tuple
    first: str | None
    last: str | None
    has_previous: bool
    has_next: bool

def encode_id(value):
    return ('o:' if isinstance(value, ObjectId) else 's:') + str(value)

def decode_id(token):
    if not isinstance(token, str) or not 3 <= len(token) <= 202:
        raise ValidationError('Page cursor is invalid. Select Retry.')
    if token.startswith('o:') and ObjectId.is_valid(token[2:]):
        return ObjectId(token[2:])
    if token.startswith('s:') and token[2:].strip() and '\x00' not in token:
        return token[2:]
    raise ValidationError('Page cursor is invalid. Select Retry.')

def request(category, size, cursor=None, direction='next'):
    category = Category.parse(category)
    if type(size) is not int or not 1 <= size <= 50:
        raise ValidationError('Page size must be a whole number from 1 to 50.')
    if direction not in ('next','previous'):
        raise ValidationError('Page direction is invalid.')
    boundary = decode_id(cursor) if cursor is not None else None
    return category, boundary
