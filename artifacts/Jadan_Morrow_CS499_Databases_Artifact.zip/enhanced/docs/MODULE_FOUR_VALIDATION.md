# Module Four validation
Date: September 26, 2026. Python 3.12.14 on Windows 11.
## Automated evidence
107 tests passed, including eight live MongoDB tests. The original 58-test baseline is retained; 48 new ranking tests and one live ranking test were added. Run python -m pytest -q -rA. Without CS499_TEST_MONGODB_URI, the eight live tests skip explicitly.
The 16 warnings concern Dash DataTable's announced future removal; the dependency is pinned. No test failures occurred.
Ranking tests cover known distances, same points, antipodes, longitude wraparound, empty inputs, k=1, k larger than the available records, deterministic ID ties, invalid inputs, rejected coordinates, a single-pass stream, capacity bounds, six randomized datasets at three k values, and actual HTTP callback behavior. Invalid input is checked before repository access.
## Browser evidence
The updated dashboard ran locally on port 8051 in authenticated MongoDB mode. Water Rescue returned three eligible records. Find nearest retained River (0.431 km) and Harbor (5.516 km) and reported one excluded record with invalid/missing coordinates. Setting k=1 retained one result. Changing inputs cleared the previous shortlist. Latitude 91 produced the validation message with no shortlist. Restoring valid inputs restored results.
The shortlist uses the complete rescue category independently of the main table text filters. The main chart and map continue to represent their original main-table population; the ranking feature does not silently replace that population.
## Benchmark evidence
See BENCHMARKS.md and benchmark_results.json for fixed-seed datasets, raw samples, median times, and peak allocations. Timing and memory were measured separately to avoid tracing overhead in the timed results.
## Limits
The 14 MongoDB records are fictional. The original shelter dataset, production deployment, accessibility audit, network performance, and real-world rescue suitability are not established. The repository still materializes matching records, so the O(k) claim applies only to ranking storage. Future database work includes streaming/batching, keyset pagination, schema validation, aggregation, and index evaluation.
