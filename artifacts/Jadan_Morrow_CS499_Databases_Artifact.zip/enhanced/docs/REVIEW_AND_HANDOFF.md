# Review and handoff guide

Jadan Morrow — October 8, 2026

## Purpose and audiences
This is an individual educational project. The workflow below is a proposed way to let other people review changes and make decisions; it is not a record of team participation or an operational rescue deployment. All fixtures are fictional.

| Reviewer perspective | Decision to support | Evidence to inspect |
|---|---|---|
| Rescue coordinator | Does the display communicate the population and limits clearly? | Table page count, full-category breed chart, excluded-location message, distance-only shortlist |
| Application maintainer | Is a change correct and maintainable? | Service/repository boundaries, ranking oracle, deterministic tie tests and regression suite |
| Database/security reviewer | Are requests bounded and access restricted? | query.py, schema/import preview, read-only role and live denied-write checks |

Use plain-language expected behavior for the coordinator and named tests/code paths for technical reviewers. Provide text summaries for charts and screenshots, keyboard-operable navigation, and written feedback options so participation does not depend on one format or level of expertise. Do not include real shelter records or credentials in review comments.

## Feedback translated into action
| Feedback | Response | Where to verify |
|---|---|---|
| Software milestone requested explicit outcome evidence | Map claims to implementation and tests | Final narratives and portfolio outcome summary |
| Algorithm review requested specific tests, user benefits, and visual evidence | Explain deterministic ties, invalid-input rejection and shortlist limits; add benchmark visuals and interface screenshot | tests/test_ranking.py; portfolio algorithm section |
| Database review on October 8 requested stronger Outcome 1 evidence | Define reviewer concerns, repeatable checks and a decision record | This guide and professional self-assessment |

## Reproduce and review
1. Read README.md. Start in sample mode before using an isolated authenticated test database. Install the pinned requirements in a virtual environment.
2. Run `python -m pytest -q`. Without the documented private MongoDB settings, 27 integration cases skip. A passing sample-only run is not a full integration result.
3. For ranking, inspect `test_ties_use_id_and_do_not_depend_on_input_order`, `test_heap_matches_full_sort_over_deterministic_records`, and `test_invalid_request_does_not_access_repository`. Accept only identical full-sort results, stable tie ordering, and validation before access.
4. For paging, inspect `test_paging_and_previous_and_full_summary` and `test_stream_ranking_reaches_beyond_first_page`. Accept traversal without repeats or omissions on a stable fixture and ranking that reaches records beyond the first page.
5. Complete live role/schema checks only in the documented isolated database. A reader must not gain maintenance rights. Record the fixture, command, result, and any skipped tests without recording credentials.
6. Review benchmark raw data before making a performance claim. Separate algorithm-only allocation from input records, process memory, database memory, and network traffic. Report regressions as well as gains.

## Example decision for a reviewer
Question: Should the app force the page_order index for every page query? Recommendation: no. It reduced documents examined on the measured rescue categories, but Reset favored _id and timings varied. Keep both indexes and let the optimizer select. Before revising that choice, collect explain statistics and repeated timings with authorized representative data. A coordinator can describe acceptable waiting time; the maintainer and database reviewer can test whether a proposed change meets it. No such external approval is claimed here.

## Suggested change record
For a proposed change, record: user problem, affected audience, evidence, alternatives, expected behavior, tests, security implications, reviewer comments, decision, and follow-up owner. Ask the reviewer to restate any unclear behavior. Resolve disagreement by comparing the acceptance checks and measured results. Keep a rejected alternative and its reason when it would help a future maintainer.

## Limits and remaining operational work
The measurements are from one computer and synthetic data. Paging and summary queries are separate reads, so concurrent writes can change later pages. Shortlists estimate spherical distance and do not establish suitability or travel time. Real deployments need authorized data, deployment security, privacy review, concurrency/load tests, and a maintenance plan for the deprecated Dash table component.
