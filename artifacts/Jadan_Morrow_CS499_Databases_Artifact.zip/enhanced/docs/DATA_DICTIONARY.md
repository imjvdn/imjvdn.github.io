# Validated database contract
- _id: unique by MongoDB; one type per collection, string (1–200 characters) or ObjectId. The JSON importer uses strings. The cursor preserves the BSON type with s: or o: prefixes. The collection validator prevents mixed ID types.
- animal_id: nonempty string, not necessarily unique across outcomes.
- name, animal_type, breed, sex_upon_outcome: required nonempty strings, maximum 200 characters. The importer also rejects whitespace-only or padded strings.
- age_upon_outcome_in_weeks: required numeric value, 0–10,000. The maximum is a defensive course-project limit, not a biological claim.
- location_lat: optional numeric -90 through 90 or null.
- location_long: optional numeric -180 through 180 or null.
Missing coordinates remain missing; they never become zero. Application ranking excludes unusable locations. The importer rejects non-finite numeric values and booleans. MongoDB strict/error validation is also exercised by live tests.

The Module Four fixture has 14 fictional records. The preview accepted 13 and rejected one invalid coordinate row (see import_preview.json). Twelve copies of each accepted record with distinct _id values form the 156-record database fixture. Repeated animal IDs and names are intentional synthetic outcomes. No original shelter dataset was obtained or tested.

Table navigation projects displayed fields and coordinates required by the selected-row map, sorted by _id. Queries are built from the rescue-category enum and validated scalar cursors. No raw user JSON operators or write controls reach the dashboard. Page size is 1–50; the driver fetches at most size+1 for lookahead. Next/Previous is designed for stable records; it is not a transaction snapshot, and concurrent inserts/deletes may change subsequent pages. Retry restarts at the beginning.

Summary is a separate full-category match/group aggregation. Its category count can change between page and summary reads. Summary storage scales with distinct breeds; table rows are bounded independently. Ranking uses a separate 100-record driver batch and the bounded heap, rather than the current page. The MongoDB server may still scan many records; bounded client memory does not imply bounded server work.
