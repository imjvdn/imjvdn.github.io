# Module Five validation
September 29, 2026: 160 tests passed, including 27 live MongoDB cases; zero skips in the configured run. See test_results.txt. The 30 warnings are existing Dash DataTable deprecation warnings. Dependencies remain pinned.

Coverage includes inherited rescue rules, configuration and map behavior; ranking correctness and ties; validated page sizes/cursors; all-category page traversal and full summaries; streaming equivalence to full sorting; failed cursor handling; typed ObjectId cursors; import duplicate/malformed reports; database schema rejection; and read-only account denial of insert/update/delete/index/schema/other-database access. HTTP navigation tests cover Next/Previous and category/page-size resets. Missing optional coordinates are tested at import and database levels.

Live setup uses a separate cs499_module5 database with 156 valid fictional records, a scoped read-only account and a separate maintenance account. The previous aac fixture remains unchanged for eight inherited integration tests. New schema and permission tests run only against disposable course fixtures. Database setup refuses existing collections and import apply refuses any rejected row.

Browser checks in MongoDB mode at local port 8052: Reset displayed 10 of 156 records; Next changed the page and enabled Previous; changing to Water Rescue reset Previous and showed 10 of 36 records. The chart showed three breeds across the full category. Ranking considered all 36 records and excluded 12 missing-location records while returning 10 candidates. This is a local Flask development server, not a production deployment.

Limits: fictional distributions, single-machine benchmarks, fixed trial order, noisy write timings, no original shelter data, no concurrent-user load or production security audit. See DATABASE_BENCHMARKS.md for measured trade-offs. The static ePortfolio does not host the Python database application.

October 4 final review: repeated the configured full suite after starting the isolated local database. All 160 tests passed (27 live, zero skips), with 30 existing deprecation warnings, in 1.07 seconds. The first attempt was interrupted because the course database was stopped; no code change was needed.
