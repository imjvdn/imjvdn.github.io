# Module Four design decisions and outcome evidence
## Instructor feedback
Read September 26, 2026: Module Three journal 15/15, Milestone Two 40/40. The instructor requested explicit evidence-to-outcome connections and measurable algorithmic evidence: Haversine, bounded heap, deterministic ties, a full-sort comparison, and benchmarks. Those requirements guide this enhancement. Milestone One received 40/40 with no specific recording corrections.
## Algorithm contract
Validate finite center coordinates and integer k in [1,100] before querying. Apply the existing rescue eligibility filter. Exclude invalid record locations and count them. Compute spherical great-circle kilometers and compare unrounded (distance, record ID) keys. Round only the display value. Geographic proximity does not measure suitability or road travel.
The heap comparator reverses the complete key, keeping the worst retained candidate at the root even when distances tie. After each input prefix it contains the best min(k, valid_count) candidates: an inferior new record cannot improve the result; a better record replaces the worst. Final sorting restores ascending output order. The heap never exceeds k.
The full-sort reference is a new comparison implementation, not a pre-existing dashboard feature. Known-distance tests independently check the shared Haversine function.
## Boundaries and trade-offs
The existing repository and stable-ID validation remain intact. Ranking accepts an iterator but the application still holds the repository result list. Database streaming remains Module Five work, as approved. A separate shortlist keeps chart/map populations unambiguous. Input changes clear old results; Find nearest explicitly computes a fresh shortlist.
## Outcome mapping
1. Instructor feedback is recorded and translated into benchmark and documentation decisions. This supports review; it does not claim a team development exercise.
2. The narrative, user guide, benchmark table, and code-review video explain the work to readers with different levels of technical experience.
3. ranking.py, the independent expected-distance tests, full-sort comparison, and repeated measurements demonstrate algorithm reasoning and evaluation of time/memory trade-offs.
4. The runnable dashboard, repository integration, eight live tests, and complete regression suite demonstrate implementing and checking a practical computing solution.
5. Finite coordinate checks, the k bound, validation before data access, and the authenticated read-only MongoDB account demonstrate input and access controls. Production security remains separate.
