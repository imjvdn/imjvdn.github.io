# Database benchmark evidence
September 29, 2026. Local MongoDB 8.0.28; Python 3.12.14; Windows 11.
10,000 deterministic fictional records. One warm-up and five timed repetitions per query, with separate traced-memory runs. Index comparisons explicitly hint each candidate; the runtime query planner remains free to choose. Results are one local run, not production guarantees.

## Page-query comparisons
Each query retrieves at most 51 records (50 rows plus lookahead).
| Category | Boundary | Index | Median ms | Documents examined | Keys examined | Returned |
|---|---|---|---:|---:|---:|---:|
| Reset | First page | _id_ | 0.375 | 51 | 51 | 51 |
| Reset | First page | filter_range | 8.963 | 10000 | 10000 | 51 |
| Reset | First page | page_order | 18.689 | 51 | 10000 | 51 |
| Reset | b-007000 | _id_ | 0.418 | 51 | 51 | 51 |
| Reset | b-007000 | filter_range | 27.887 | 10000 | 10000 | 51 |
| Reset | b-007000 | page_order | 24.560 | 10000 | 10000 | 51 |
| Water Rescue | First page | _id_ | 1.059 | 211 | 211 | 51 |
| Water Rescue | First page | filter_range | 6.678 | 2310 | 2312 | 51 |
| Water Rescue | First page | page_order | 1.435 | 51 | 67 | 51 |
| Water Rescue | b-007000 | _id_ | 1.845 | 217 | 217 | 51 |
| Water Rescue | b-007000 | filter_range | 7.686 | 2310 | 2312 | 51 |
| Water Rescue | b-007000 | page_order | 0.975 | 51 | 68 | 51 |
| Mountain or Wilderness Rescue | First page | _id_ | 0.926 | 167 | 167 | 51 |
| Mountain or Wilderness Rescue | First page | filter_range | 9.266 | 3076 | 3079 | 51 |
| Mountain or Wilderness Rescue | First page | page_order | 0.916 | 51 | 90 | 51 |
| Mountain or Wilderness Rescue | b-007000 | _id_ | 1.038 | 166 | 166 | 51 |
| Mountain or Wilderness Rescue | b-007000 | filter_range | 5.606 | 3076 | 3079 | 51 |
| Mountain or Wilderness Rescue | b-007000 | page_order | 0.844 | 51 | 88 | 51 |
| Disaster or Individual Tracking | First page | _id_ | 0.991 | 134 | 134 | 51 |
| Disaster or Individual Tracking | First page | filter_range | 14.354 | 3845 | 3847 | 51 |
| Disaster or Individual Tracking | First page | page_order | 1.540 | 51 | 71 | 51 |
| Disaster or Individual Tracking | b-007000 | _id_ | 0.646 | 131 | 131 | 51 |
| Disaster or Individual Tracking | b-007000 | filter_range | 4.118 | 3845 | 3847 | 51 |
| Disaster or Individual Tracking | b-007000 | page_order | 0.908 | 51 | 71 | 51 |

## Index decision
Keep the automatic _id index and offer page_order for rescue-filter pagination. Install it using tools.install_indexes. Do not install filter_range for this workload: it examined thousands of records and was slower for these bounded sorted page requests. page_order reduces documents examined to 51 for the tested rescue pages, but it is not faster in every timing comparison. Reset strongly favors _id. No forced production hint is used. Repeat measurements with real distributions before changing this decision.
page_order keys: animal_type, sex_upon_outcome, _id, breed, age_upon_outcome_in_weeks. filter_range keys: animal_type, sex_upon_outcome, breed, age_upon_outcome_in_weeks. All ascending. The in-list breed and age range compete with global _id sorting.

## Deep page, payload and memory
At the same 7,001-record boundary, skip median was 3.240 ms and keyset median was 0.445 ms; returned IDs matched.
JSON row payload: 2,313,087 bytes for 10,000 records versus 11,571 bytes for 50 rows. This measures serialized table rows only, not HTTP headers, summary data or total browser traffic.
Materialized read plus ranking: 47.149 ms, 13,189,908 median traced peak bytes. Batched read plus ranking: 145.577 ms, 160,471 bytes. IDs matched. Streaming is slower here, consistent with more cursor round trips at batch size 100; the measurement does not isolate that cause. It substantially reduces Python allocation. Tracemalloc excludes MongoDB server memory and is not process RSS. Both runs include local database reads and normalization; input fixture generation and browser rendering are excluded.

## Storage and write cost
Observed indexSizes in bytes: {"_id_": 4096, "filter_range": 73728, "page_order": 360448}. Baseline totalIndexSize before candidate construction: 4096. These are storage-engine allocation snapshots, influenced by compression and checkpoint timing; they are not exact logical bytes per entry.
For each index configuration, six fresh isolated collections received 2,000 records; the first is a warm-up and the remaining five form the median. Index construction is excluded from insert duration. The order was fixed, not randomized, and timings vary substantially. These results do not establish a reliable causal write-overhead percentage.
- baseline: 53.465 ms median; samples 37.996, 29.705, 53.465, 55.221, 74.238 ms.
- filter_range: 58.622 ms median; samples 74.029, 21.462, 79.474, 28.878, 58.622 ms.
- page_order: 42.756 ms median; samples 34.142, 42.756, 28.511, 70.420, 61.712 ms.
Index build durations (single observations, not medians): {"filter_range": 36.38869999849703, "page_order": 52.28420000639744}

Raw samples, explain execution statistics and environment are in database_benchmark.json. Repeat with a fresh CS499_BENCHMARK_RUN identifier; the script refuses to replace collections.
References: https://www.mongodb.com/docs/v8.0/reference/method/cursor.skip/ and https://www.mongodb.com/docs/v8.0/reference/explain-results/
