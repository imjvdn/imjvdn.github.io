# Ranking benchmark results

Measured September 26, 2026. Python 3.12.14; Windows-11-10.0.26200-SP0.

Fixed seed 499. Input sizes: 1,000, 10,000, 100,000; k: 10 and 100. One warm-up and five timing runs per configuration; five separate tracemalloc runs. Inputs are built before measurement. Both algorithms receive an iterator over the same prebuilt records. Every measured result matches the full-sort reference exactly.

| n | k | Heap median ms | Sort median ms | Heap peak KiB | Sort peak KiB |
|---:|---:|---:|---:|---:|---:|
| 1,000 | 10 | 1.314 | 1.462 | 3.65 | 181.09 |
| 1,000 | 100 | 1.614 | 1.361 | 25.88 | 181.09 |
| 10,000 | 10 | 13.058 | 24.538 | 3.65 | 1802.55 |
| 10,000 | 100 | 14.483 | 19.408 | 25.88 | 1802.55 |
| 100,000 | 10 | 273.618 | 345.706 | 3.65 | 17970.02 |
| 100,000 | 100 | 262.363 | 376.269 | 25.88 | 17970.02 |

## Interpretation

The heap retains at most k candidates and shows substantially lower temporary allocation in these ranking-only measurements. At n=1,000 and k=100, full sorting is faster; lower asymptotic cost does not guarantee lower wall time for small inputs. The two methods compute the same distances, so much of the work is shared. Timings are observations on one computer, not a promised speedup.

Tracemalloc reports traced Python allocations, not total process RAM or MongoDB memory. Prebuilt Animal records, database query time, network transfer, and browser rendering are excluded. The current repository still materializes all matching records, so overall dashboard input storage remains O(n). A batched iterator and server-side pagination remain later database work.

For n records, k>=2, heap selection is O(n log k), followed by O(k log k) ordering, with O(k) extra retained storage. For k=1, scanning is O(n). Full sorting is O(n log n) with O(n) candidate storage. Bounds assume fixed-width numeric values and bounded ID comparisons. Input record IDs must be unique.

Raw timings, allocation samples, and retained counts: benchmark_results.json. Reproduce with python benchmark_ranking.py from enhanced/.