# Module Five decisions and outcome evidence

The approved plan called for database paging, aggregation, streaming, import/schema checks, least privilege, and measured index choice. Each is implemented. The prior software architecture and ranking algorithm remain covered by regression tests.

| Finding | Change | Evidence and limit |
|---|---|---|
| Full results reached the browser | Projected keyset pages, max 50 displayed rows | query.py, repository.py, traversal and HTTP tests; concurrent reads are not a snapshot |
| A page-only chart would misrepresent the category | Separate match/group breed aggregation | Summary oracle tests and browser check; distinct-breed output is not capped |
| Ranking input still occupied O(n) memory | Projected batched cursor feeds the existing heap | Exact full-sort equivalence, failure tests and 10,000-record measurements; measured streaming was slower but used less traced memory |
| Imports and malformed fields were unchecked | Preview report and strict collection validator | Rejected-row examples, live code-121 failures, missing-coordinate preservation |
| Privileged access could reach the app | Scoped reader and separate maintenance account | Six live code-13 denials; local authenticated test environment only |
| An index improvement needed evidence | Compare _id, filter_range and page_order | 24 explain/timing configurations, payload, storage and write results; page_order not fastest in every case and never forced in the app |

Outcome 1: instructor feedback informed explicit evidence mapping; individual work does not establish team collaboration. Outcome 2: README, narrative, dictionary and measured reports explain decisions to a reviewer. Outcome 3: keyset versus skip and streaming versus materialization compare time and space trade-offs. Outcome 4: repository integration, schema, aggregation, reproducible tools and live tests demonstrate a working computing solution. Outcome 5: bounded validated requests, projected reads, safe failures and denied writes demonstrate security-minded design. A final professional self-assessment and later feedback incorporation remain.

Milestone Two received 40/40 and requested explicit outcome evidence. This mapping addresses that feedback. October 4 review: the Module Four journal received 15/15 and the algorithm milestone received 40/40. Feedback requested course-material connections, specific test evidence, clear user benefits and later portfolio demonstrations. The updated journal and database narrative address the first three; final algorithm portfolio evidence remains scheduled for Module Six.
