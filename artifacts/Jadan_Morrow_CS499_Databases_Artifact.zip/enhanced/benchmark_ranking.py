"""Deterministic ranking-only comparison; excludes DB/network/input storage.

One warm-up; five timed runs without tracing, plus five separate traced runs.
Outputs raw samples, medians, Python/platform details, and exact correctness checks.
"""
from pathlib import Path
from time import perf_counter
from statistics import median
import gc, json, platform, random, tracemalloc
from rescue_dashboard.domain import Animal
from rescue_dashboard.ranking import nearest_heap, nearest_full_sort

def dataset(n):
    rng=random.Random(499)
    return [Animal(f'{i:09}','DEMO','Synthetic','Dog','Labrador Retriever Mix','Intact Female',30,
                   rng.uniform(-90,90),rng.uniform(-180,180)) for i in range(n)]

def run():
    report={'seed':499,'repetitions':5,'warmups':1,'python':platform.python_version(),
            'platform':platform.platform(),'scope':'Ranking only; prebuilt input excluded; timing and memory measured separately.', 'results':[]}
    for n in [1000,10000,100000]:
        records=dataset(n)
        for k in [10,100]:
            expected=nearest_full_sort(iter(records),30.2672,-97.7431,k)
            assert nearest_heap(iter(records),30.2672,-97.7431,k).candidates==expected.candidates
            for name,fn in [('heap',nearest_heap),('full_sort',nearest_full_sort)]:
                fn(iter(records),30.2672,-97.7431,k)
                durations=[]; peaks=[]
                for _ in range(5):
                    gc.collect(); start=perf_counter()
                    result=fn(iter(records),30.2672,-97.7431,k)
                    durations.append((perf_counter()-start)*1000)
                    assert result.candidates==expected.candidates
                for _ in range(5):
                    gc.collect(); tracemalloc.start()
                    result=fn(iter(records),30.2672,-97.7431,k)
                    peaks.append(tracemalloc.get_traced_memory()[1]); tracemalloc.stop()
                    assert result.candidates==expected.candidates
                row={'n':n,'k':k,'algorithm':name,'median_ms':round(median(durations),3),
                     'median_peak_bytes':int(median(peaks)),'raw_ms':durations,'raw_peak_bytes':peaks,
                     'peak_retained':result.peak_retained,'ordered_results_match':True}
                report['results'].append(row)
                print(n,k,name,row['median_ms'],row['median_peak_bytes'],flush=True)
    Path('docs/benchmark_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__': run()
