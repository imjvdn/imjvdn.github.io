# Original artifact baseline

Source: CS340_ProjectTwo_JadanMorrow_original.zip, retained privately in the local sources directory.

This folder contains both original code files and the original logo. The notebook code is retained; stored outputs and execution counts are cleared. The original module's username and password literals are replaced with REDACTED_FOR_SUBMISSION. These are the only intentional baseline changes. Credential redaction does not change the original architecture or rescue query logic, and does not rotate or revoke the historical credentials.

The original Word readme is not a code file and is not reproduced here. The enhanced application has its own complete README. The untouched private archive remains available locally for provenance; do not publish it as part of the ePortfolio without reviewing its credentials and content.
