from dataclasses import replace
import json
from unittest.mock import MagicMock
import pytest
from pymongo.errors import ServerSelectionTimeoutError
from rescue_dashboard.domain import Animal, Category, ValidationError, eligible, rescue_query
from rescue_dashboard.config import Settings
from rescue_dashboard.repository import InMemoryRepository, MongoRepository, RepositoryError, normalize
from rescue_dashboard.service import RescueService, selected_animal, breed_counts
from rescue_dashboard.app import create_app


def record(**changes):
    data = {'_id': 'r1', 'animal_id': 'A1', 'name': 'River', 'animal_type': 'Dog',
            'breed': 'Labrador Retriever Mix', 'sex_upon_outcome': 'Intact Female',
            'age_upon_outcome_in_weeks': 26, 'location_lat': 30.27, 'location_long': -97.74}
    data.update(changes)
    return Animal.from_document(data)


@pytest.mark.parametrize('category,breed,sex,lower,upper', [
    (Category.WATER, 'Labrador Retriever Mix', 'Intact Female', 26, 156),
    (Category.MOUNTAIN, 'German Shepherd', 'Intact Male', 26, 156),
    (Category.DISASTER, 'Bloodhound', 'Intact Male', 20, 300)])
@pytest.mark.parametrize('position', ['below', 'lower', 'upper', 'above'])
def test_eligibility_age_boundaries(category, breed, sex, lower, upper, position):
    age = {'below': lower-.1, 'lower': lower, 'upper': upper, 'above': upper+.1}[position]
    animal = record(breed=breed, sex_upon_outcome=sex, age_upon_outcome_in_weeks=age)
    assert eligible(animal, category) == (position in ('lower', 'upper'))


@pytest.mark.parametrize('changes', [ {'animal_type': 'Cat'}, {'breed': 'Poodle'},
    {'sex_upon_outcome': 'Intact Male'}, {'age_upon_outcome_in_weeks': None}])
def test_water_rejects_wrong_attributes(changes):
    assert not eligible(record(**changes), Category.WATER)


@pytest.mark.parametrize('lat,lon', [(None, 0), ('bad', 0), (float('nan'), 0),
    (0, float('inf')), (91, 0), (-91, 0), (0, 181), (0, -181), (True, 0)])
def test_invalid_coordinates_do_not_make_a_marker(lat, lon):
    assert record(location_lat=lat, location_long=lon).coordinates is None


@pytest.mark.parametrize('lat,lon', [(0, 0), (-90, -180), (90, 180), ('30.2', '-97.7')])
def test_valid_coordinates_include_zero_and_boundaries(lat, lon):
    assert record(location_lat=lat, location_long=lon).coordinates == (float(lat), float(lon))


def test_reset_includes_animals_not_eligible_for_rescue():
    animals = [record(), record(_id='r2', animal_type='Cat')]
    assert RescueService(InMemoryRepository(animals)).search('Reset').animals == tuple(animals)


@pytest.mark.parametrize('choice', ['unknown', None, {'$where': 'anything'}])
def test_invalid_category_does_not_call_repository(choice):
    repo = MagicMock()
    result = RescueService(repo).search(choice)
    assert result.failed and result.animals == ()
    repo.find.assert_not_called()


def test_empty_results_are_normal():
    result = RescueService(InMemoryRepository([])).search('Reset')
    assert not result.failed and result.animals == () and 'No animals' in result.message


def test_failure_is_safe_and_retry_recovers(caplog):
    repo = MagicMock()
    repo.find.side_effect = [RepositoryError('SECRET credential and host'), [record()]]
    service = RescueService(repo)
    failure = service.search('Reset')
    assert failure.failed and not failure.animals and 'Retry' in failure.message
    assert 'SECRET' not in failure.message + caplog.text
    assert len(service.search('Reset').animals) == 1


def test_selection_is_id_based_after_reorder_and_cleared_if_absent():
    first, second = record(), record(_id='r2', name='Peak')
    assert selected_animal([second, first], ['r1']) is first
    assert selected_animal([second], ['r1']) is None
    assert selected_animal([], ['r1']) is None
    assert selected_animal([first], [-1]) is None


def test_identity_is_not_animal_id_or_row_position():
    # Outcome records may share an animal_id; Mongo _id remains the unique identity.
    animals = normalize([record().to_row(), record(_id='r2').to_row()])
    assert animals[0].animal_id == animals[1].animal_id
    assert animals[0].record_id != animals[1].record_id
    with pytest.raises(ValidationError):
        normalize([record().to_row(), record().to_row()])
    with pytest.raises(ValidationError):
        Animal.from_document({'animal_id': 'A1'})


def test_breed_chart_groups_under_two_percent_not_at_boundary():
    animals = [record(_id=str(i), breed='Common') for i in range(97)]
    animals += [record(_id='97', breed='Rare'), record(_id='98', breed='Two'), record(_id='99', breed='Two')]
    assert breed_counts(animals) == {'Common': 97, 'Other': 1, 'Two': 2}
    assert breed_counts([]) == {}


def test_settings_defaults_and_no_secret_in_repr():
    settings = Settings.from_environment({})
    assert not settings.debug and settings.host == '127.0.0.1' and settings.source == 'sample'
    assert 'SECRET' not in repr(replace(settings, mongo_uri='mongodb://user:SECRET@localhost'))


@pytest.mark.parametrize('env', [{'RESCUE_DATA_SOURCE': 'other'}, {'RESCUE_DATA_SOURCE': 'mongo'},
    {'RESCUE_PORT': 'x'}, {'RESCUE_PORT': '0'}, {'RESCUE_PORT': '65536'}, {'RESCUE_DEBUG': 'maybe'}])
def test_invalid_configuration_fails_clearly(env):
    with pytest.raises(ValidationError):
        Settings.from_environment(env)


def test_mongo_adapter_builds_query_and_retains_id():
    collection = MagicMock()
    cursor = collection.find.return_value.__enter__.return_value
    cursor.__iter__.return_value = iter([record().to_row()])
    result = MongoRepository(collection).find(Category.WATER)
    query, projection = collection.find.call_args.args
    assert query == {'animal_type': 'Dog', 'breed': {'$in': ['Labrador Retriever Mix',
        'Chesapeake Bay Retriever', 'Newfoundland']}, 'sex_upon_outcome': 'Intact Female',
        'age_upon_outcome_in_weeks': {'$gte': 26, '$lte': 156}}
    assert projection['_id'] == 1 and result[0].record_id == 'r1'


def test_driver_failure_is_wrapped_without_credentials():
    collection = MagicMock()
    collection.find.side_effect = ServerSelectionTimeoutError('SECRET uri')
    with pytest.raises(RepositoryError) as error:
        MongoRepository(collection).find(Category.RESET)
    assert 'SECRET' not in str(error.value)


def test_callback_selection_reset_and_map_states():
    app = create_app(repository=InMemoryRepository([record(), record(_id='r2', location_lat=None)]))
    rows, message, selected_rows, selected_ids, page = app.rescue_callbacks['load']('Reset', 0)
    assert len(rows) == 2 and selected_rows == selected_ids == [] and page == 0
    views = app.rescue_callbacks['views']
    _, map_view = views(rows, ['r1'], rows)
    assert 'Location for River' in json.dumps(map_view, default=lambda x: x.to_plotly_json())
    _, invalid = views(rows, ['r2'], rows)
    assert 'missing or invalid' in invalid.children
    _, stale = views([rows[1]], ['r1'], rows)
    assert 'Select an animal' in stale.children
    chart, empty_map = views([], ['r1'], rows)
    assert chart.children == 'No animals to chart.'
    assert empty_map.children == 'No animal location to display.'


def test_http_layout_and_real_callback_round_trip():
    app = create_app(repository=InMemoryRepository([record()]))
    client = app.server.test_client()
    assert client.get('/').status_code == 200
    assert client.get('/_dash-layout').status_code == 200
    output = next(key for key in app.callback_map if 'animals.data' in key)
    response = client.post('/_dash-update-component', json={
        'output': output, 'outputs': [{'id': 'animals', 'property': 'data'},
            {'id': 'status', 'property': 'children'}, {'id': 'animals', 'property': 'selected_rows'},
            {'id': 'animals', 'property': 'selected_row_ids'}, {'id': 'animals', 'property': 'page_current'}],
        'inputs': [{'id': 'category', 'property': 'value', 'value': 'Water Rescue'},
                   {'id': 'retry', 'property': 'n_clicks', 'value': 0}],
        'state': [], 'changedPropIds': ['category.value']})
    assert response.status_code == 200
    assert response.json['response']['animals']['data'][0]['id'] == 'r1'


def test_missing_sample_file_preserves_interface(tmp_path):
    app = create_app(Settings(sample_path=tmp_path/'missing.json'))
    assert app.server.test_client().get('/_dash-layout').status_code == 200
    rows, message, *_ = app.rescue_callbacks['load']('Reset', 0)
    assert rows == [] and 'Unable to load' in message


def test_close_releases_database_client():
    client = MagicMock()
    MongoRepository(MagicMock(), client).close()
    client.close.assert_called_once()
