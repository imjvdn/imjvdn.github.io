"""Opt-in tests against a real MongoDB instance seeded with data/sample_animals.json.

Set CS499_TEST_MONGODB_URI privately to a read-only account for that fixture database.
The write-permission probe uses an impossible filter and upsert=False; it cannot alter data.
"""
import json
import os
from dataclasses import replace
import pytest
from pymongo import MongoClient
from pymongo.errors import OperationFailure
from rescue_dashboard.config import Settings
from rescue_dashboard.domain import Category
from rescue_dashboard.repository import MongoRepository, InMemoryRepository
from rescue_dashboard.app import create_app

pytestmark = pytest.mark.skipif(not os.environ.get('CS499_TEST_MONGODB_URI'),
                                reason='A live fixture database was not configured.')

@pytest.fixture
def settings():
    return Settings(source='mongo', mongo_uri=os.environ['CS499_TEST_MONGODB_URI'])

@pytest.mark.parametrize('category,count', [(Category.RESET,14), (Category.WATER,3),
    (Category.MOUNTAIN,5), (Category.DISASTER,5)])
def test_live_queries_match_sample_records(settings, category, count):
    repo = MongoRepository.connect(settings)
    try:
        actual = repo.find(category)
        expected = InMemoryRepository.from_file(settings.sample_path).find(category)
        assert len(actual) == count
        assert {a.record_id for a in actual} == {a.record_id for a in expected}
    finally:
        repo.close()

def test_live_account_denies_unauthenticated_reads_and_writes(settings):
    with MongoClient(settings.mongo_uri) as client:
        db = client[settings.database]
        assert db[settings.collection].count_documents({}) == 14
        with pytest.raises(OperationFailure) as error:
            db[settings.collection].update_one({'_id': {'$exists': False}},
                {'$set': {'permission_probe': True}}, upsert=False)
        assert error.value.code == 13
    with MongoClient('mongodb://127.0.0.1:27018/', serverSelectionTimeoutMS=2000) as client:
        with pytest.raises(OperationFailure) as error:
            client[settings.database][settings.collection].find_one({})
        assert error.value.code == 13

def test_live_http_callback_and_map(settings):
    app = create_app(settings)
    try:
        client = app.server.test_client()
        output = next(key for key in app.callback_map if 'animals.data' in key)
        response = client.post('/_dash-update-component', json={
            'output': output, 'outputs': [{'id':'animals','property':p} for p in ['data']]
              + [{'id':'status','property':'children'}]
              + [{'id':'animals','property':p} for p in ['selected_rows','selected_row_ids','page_current']],
            'inputs':[{'id':'category','property':'value','value':'Water Rescue'},
                      {'id':'retry','property':'n_clicks','value':0}],
            'state':[], 'changedPropIds':['category.value']})
        assert response.status_code == 200
        rows = response.json['response']['animals']['data']
        assert len(rows) == 3
        river = next(row for row in rows if row['name'] == 'River')
        chart, location = app.rescue_callbacks['views'](rows,[river['id']],rows)
        assert sum(chart.figure['data'][0]['values']) == 3
        assert 'Location for River' in json.dumps(location, default=lambda x:x.to_plotly_json())
        bay = next(row for row in rows if row['name'] == 'Bay')
        _, location = app.rescue_callbacks['views'](rows,[bay['id']],rows)
        assert 'missing or invalid' in location.children
    finally:
        app.rescue_repository.close()

def test_live_empty_collection(settings):
    repo = MongoRepository.connect(replace(settings, collection='empty_fixture'))
    try:
        assert repo.find(Category.RESET) == []
    finally:
        repo.close()
