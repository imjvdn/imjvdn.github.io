"""Seed an EMPTY local test collection with the included fictional records.

Use a separate setup account: set MONGODB_SETUP_URI privately in the environment.
The dashboard should use its own read-only account via MONGODB_URI.
"""
import json
import os
from pathlib import Path
from pymongo import MongoClient

def main():
    uri = os.environ.get('MONGODB_SETUP_URI')
    if not uri:
        raise SystemExit('Set MONGODB_SETUP_URI privately to a setup account connection string.')
    records = json.loads((Path(__file__).resolve().parents[1]/'data/sample_animals.json').read_text())
    with MongoClient(uri, serverSelectionTimeoutMS=5000) as client:
        collection = client[os.environ.get('MONGODB_DATABASE','aac')][os.environ.get('MONGODB_COLLECTION','animals')]
        if collection.count_documents({}):
            raise SystemExit('Collection is not empty; no records were changed.')
        collection.insert_many(records)
        print('Imported 14 fictional test records.')

if __name__ == '__main__':
    main()
