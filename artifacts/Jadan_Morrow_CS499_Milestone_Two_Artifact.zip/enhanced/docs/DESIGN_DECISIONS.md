# Design decisions and review response

## Scope

Module Three implements Category One of the reviewed CS 340 enhancement plan. It changes architecture, configuration, validation, error handling, testability, and documentation. It does not claim completed Category Two ranking or Category Three database optimization.

## Instructor feedback

The Module One feedback endorsed a presentation/service/repository separation, dependency injection, in-memory testing, a MongoDB adapter, typed records, configuration, error handling, logging, and automated tests. The Module Two journal feedback asked for test cases or controlled measurements to verify findings. The code review feedback described the planned enhancements as practical and aligned with the findings. These comments were read in Brightspace on September 19, 2026. No team review or instructor review of this new implementation is claimed.

## Findings and implemented responses

| Original finding | Implemented response | Evidence |
| --- | --- | --- |
| Notebook startup requires MongoDB and combines interface and rules | Standalone app factory, Settings, domain rules, RescueService, repository adapters | Sample-mode startup; HTTP layout and callback tests |
| Unknown rescue value falls through to Reset | Enum validation rejects unsupported choices before repository access | Invalid-category tests, including a dictionary input |
| Map reads unchecked row positions | Stable IDs; absent selection produces a prompt | Reordered and removed selection tests; browser selection |
| Coordinates may be missing or invalid | Finite numeric checks and range validation before marker creation | Boundary, NaN, infinity, boolean, missing, and string tests |
| Database failure has no clear user state | RepositoryError is mapped to safe UI text; retry reissues reads | Simulated failure followed by success; no secret in logs |
| Credentials are embedded; debug enabled | Environment configuration; private URI repr; debug off; loopback bind | Configuration tests; observed startup with debug off |
| No repeatable tests or complete setup instructions | Pinned dependency file, fictional data, pytest suite, README | Recorded test output and manual browser checks |

## Tradeoffs

Keeping Dash and its table avoids changing both the framework and architecture at once. The dependency is pinned because DataTable is deprecated for a future major Dash release. Full result loading is intentionally retained and documented; showing ten table rows does not mean MongoDB reads only ten. A read-only repository interface narrows application behavior but does not prove the database account lacks write permissions. The local fixture database now rejects a no-match write from the dashboard account. Broader production permission tests remain later work.

Selection is cleared after rescue-category changes and refreshes. Table sorting uses stable IDs. Table filtering suppresses the map if the selected ID is no longer visible. These explicit rules replace the original fallback to a positional first row. Code remains independently testable, though additional files and model conversions add maintenance overhead compared with a single notebook.

## Course outcomes

1. Collaboration: clear boundaries and documented response to instructor feedback support future review; no fabricated teamwork claim.
2. Communication: README, design notes, review video, and accompanying narrative explain the changes and limits.
3. Algorithms: still planned; current boundary and chart tests do not replace the promised heap/reference comparison and benchmarks.
4. Computing techniques and tools: standalone Dash app, dependency injection, typed model, adapters, pinned dependencies, and repeatable tests.
5. Security mindset: safe configuration, checked inputs, valid locations, safe error messages, and no application write interface. The local read-only account is now verified; broader database permissions and deployment security remain separate work.
