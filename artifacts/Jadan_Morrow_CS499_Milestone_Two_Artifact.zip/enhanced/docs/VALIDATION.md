# Validation record

Updated: September 20, 2026. Local Windows environment, Python 3.12, dependencies pinned in requirements.txt.

## Automated checks

Command: `python -m pytest -q -rA`

Result: 58 passed, 4 deprecation warnings, 0 failures. Full output is in test_results.txt. `python -m pip check` reported no broken requirements.

The warnings identify the planned future removal of Dash's built-in DataTable. The tested Dash 3.4.0 is pinned for this milestone. The tests cover rescue category age boundaries; eligibility attributes; coordinate bounds, missing values, booleans, infinity and NaN; Reset and empty results; validation before data access; safe failure and retry recovery; selection by ID after reordering or filtering; duplicate and missing IDs; chart grouping; environment configuration; Mongo query construction and exception wrapping; callback view states; an actual HTTP callback request; missing sample files; and client cleanup.

## Browser observations

The application started with debug off at 127.0.0.1:8050. The running local app was inspected in a browser.

- Reset initially reported 14 fictional animals.
- Water Rescue reported 3: River, Harbor, and Bay, including the inclusive age endpoints 26 and 156.
- Selecting River rendered a location heading, a map marker, and visible map tiles, alongside the breed chart.
- Selecting Bay, whose sample coordinates are missing, replaced the map with an explanatory message.
- Filtering the Name column to ZZZ produced zero visible rows and cleared both chart and map.

## Limits

The original shelter dataset was not used. Live integration and read-only access were verified only in the isolated local fixture database described below; this is not a production security assessment. No performance benchmarks, ranking feature, server-side paging, database schema rules, or index experiments are claimed. The sample set is intentionally small and fictional; its behavior is not evidence of real-world rescue suitability or production capacity. Browser checks complement the unit and HTTP tests but are not a complete accessibility audit.

## Live MongoDB verification — September 20, 2026

MongoDB Community 8.0.28 was installed from the official Windows ZIP; SHA-256 matched the publisher checksum. It runs separately from the existing MongoDB installation, bound to 127.0.0.1:27018, with authentication enabled. The aac.animals collection contains the 14 included fictional records. The dashboard uses an account with only the read role on aac. Local account secrets are Windows-encrypted outside the workspace and are not in this archive.

The seven opt-in tests in tests/test_mongo_integration.py passed against the real server: four rescue categories (Reset 14, Water 3, Mountain 5, Disaster 5), authentication/write rejection, a real Dash HTTP callback plus chart/map states, and an empty collection. A no-match update with upsert disabled returned authorization code 13; an unauthenticated read also returned code 13. These tests use no mock database driver. All 58 tests passed in one run with the live test connection configured.

Browser verification in MongoDB mode confirmed 14 initial records, Water Rescue returning 3 records, and River's map marker. Gracefully stopping this isolated MongoDB instance and clicking Retry produced the safe failure message and empty views. After restarting the instance, Retry restored all 3 Water Rescue records without restarting the dashboard. The old MongoDB service was not changed.

To repeat the live suite, use the setup in README.md and set CS499_TEST_MONGODB_URI privately. Without that variable, the seven live tests are explicitly skipped. The test fixture expects aac.animals and a nonexistent/empty aac.empty_fixture collection on the local port 27018. The original 51 tests continue to run without MongoDB.
