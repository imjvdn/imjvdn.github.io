# Grazioso Salvare Animal Rescue Dashboard

Jadan Morrow — CS 499 Milestone Two, Software Design and Engineering.

This standalone Python application enhances the April 19, 2026 CS 340 notebook. It preserves the three rescue filters, reset, sortable/filterable table, breed chart, column highlighting, and selected-animal map. The first enhancement separates responsibilities and makes failure behavior testable. This is a local educational application, not a production deployment.

## Run with the included sample data

Requires Python 3.12. From this `enhanced` directory:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m rescue_dashboard.app
```

Open http://127.0.0.1:8050. Stop with Ctrl+C. On macOS/Linux use `python3.12 -m venv .venv` and `.venv/bin/python` for the remaining commands. All pinned dependencies, including the test runner, are in `requirements.txt`. Internet access is needed for installation and map tiles, but not for sample filtering or automated tests after installation.

The 14 records in `data/sample_animals.json` are fictional, locally authored examples. They are not the original Austin Animal Center dataset. Some intentionally have missing or out-of-range coordinates. Expected rescue totals are Water 3, Mountain 5, Disaster 5, and Reset 14; categories can overlap. These tiny fixtures do not establish production performance or suitability of a real animal for rescue training.

## Use your MongoDB environment

In the same terminal, set `RESCUE_DATA_SOURCE` to `mongo`, `MONGODB_URI` privately to your connection string, and optionally `MONGODB_DATABASE` and `MONGODB_COLLECTION` (defaults `aac` and `animals`). Launch with the same command. Use a MongoDB account restricted to reading the required collection. Local integration verification used MongoDB 8.0.28 with authentication and a read-only account; see docs/VALIDATION.md. Configure permissions separately for your own database.

Mongo records require `_id`; `animal_id` is a display identifier and may repeat across outcome records. Expected fields are `name`, `animal_type`, `breed`, `sex_upon_outcome`, numeric `age_upon_outcome_in_weeks`, and optional numeric `location_lat` and `location_long`. Coordinates must be finite and within latitude [-90, 90] and longitude [-180, 180]. Missing locations remain missing. Numeric coordinate strings are accepted by the presentation model. Mongo eligibility queries expect numeric ages in storage. The later database enhancement will address import validation and schema enforcement.

The `.env.example` file documents settings; the application does not automatically load `.env`. `RESCUE_PORT` defaults to 8050; change it if occupied. The server binds only to 127.0.0.1. Debug is off unless `RESCUE_DEBUG=true` is explicitly set for local development. Invalid settings produce a safe startup message. After changing settings or repairing a missing sample file, restart the application. A transient MongoDB read failure can be retried with the Retry / Refresh button.

## Design and behavior

```text
Browser controls
    -> app.py callbacks (presentation)
    -> RescueService (validation, result and error states)
    -> AnimalRepository protocol
        -> InMemoryRepository (fictional records)
        -> MongoRepository (fixed read queries)

domain.py: typed Animal records, rescue rules, coordinates, and identity
config.py: environment settings and safe defaults
```

The factory accepts an injected repository, so tests can simulate results and failures without a live database. The enhanced application exposes no update or delete methods. Mongo connection details are excluded from configuration representations, UI error messages, and application error logs. It does not log raw driver exceptions.

Each row has a permanent `id` derived from Mongo `_id` or the sample `_id`. Selection uses that identity, not a row offset. Sorting does not change which animal is selected. Changing category or refreshing clears selection and returns to page one. A selected animal excluded by a table filter produces a selection prompt instead of showing another animal; restoring the filter may restore that ID's selection. Empty results clear both chart and map. Invalid locations retain the row but replace the map with an explanation. Coordinates (0, 0) are valid and are not treated as missing.

The chart represents all rows remaining after the browser's table filters, across pages. Breeds under 2% are grouped as Other. Table paging remains client-side, with 10 rows displayed per page; all matching results are still loaded. No performance gain is claimed. Haversine ranking, bounded heaps, server-side pagination, database schema rules, permission verification, and measured index selection are reserved for later enhancements.

## Verify

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

See `docs/VALIDATION.md` and `docs/test_results.txt` for the actual run and limits. Tests cover rescue boundaries, invalid inputs, stable identity, chart grouping, safe failure and retry, configuration, adapter behavior, and an HTTP callback. The original driver unit tests use mocks. Seven additional opt-in tests passed against a real local MongoDB installation with fictional records; they skip unless CS499_TEST_MONGODB_URI is configured. Dash 3.4.0 emits a deprecation warning for its built-in DataTable. It is retained and pinned to preserve the original interface within this milestone; a future Dash major-version upgrade will require evaluating its replacement.

## Source and review references

- Plotly. DataTable interactivity and stable row IDs: https://dash.plotly.com/datatable/interactivity
- Plotly. DataTable reference: https://dash.plotly.com/datatable/reference
- The original project and credential-redaction notes are in the sibling `original` directory.
- `docs/DESIGN_DECISIONS.md` connects the review findings and instructor feedback to this implementation.

## Repeat the optional live MongoDB tests

1. Install MongoDB Community and start an isolated instance bound to 127.0.0.1:27018 with authorization enabled. Create a setup administrator using MongoDB's localhost exception during initial provisioning. Do not reuse a production database.
2. Create a separate user on aac with only the built-in read role for aac. Keep administrator and dashboard credentials separate.
3. Set MONGODB_SETUP_URI privately to the setup account's authenticated URI. From this directory run `python tools/seed_mongo.py` using the installed virtual environment. It imports data/sample_animals.json only into an empty collection and refuses to overwrite existing data. Remove MONGODB_SETUP_URI after seeding.
4. Set RESCUE_DATA_SOURCE=mongo and MONGODB_URI privately to the read-only account URI, with authSource=aac. The defaults are MONGODB_DATABASE=aac and MONGODB_COLLECTION=animals. Launch `python -m rescue_dashboard.app` using the virtual environment.
5. Set CS499_TEST_MONGODB_URI to that same read-only URI and run `python -m pytest -q -rA`. The fixture tests expect exactly the 14 included records, plus an empty or nonexistent aac.empty_fixture collection. The unauthenticated-read probe targets 127.0.0.1:27018. No passwords or actual authenticated connection strings are included in this submission.

MongoDB setup references: https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-windows-zip/ and https://www.mongodb.com/docs/manual/reference/built-in-roles/.
