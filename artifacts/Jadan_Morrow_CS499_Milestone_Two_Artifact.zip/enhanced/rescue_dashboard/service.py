"""Application behavior with no Dash, HTML, or MongoDB client dependency."""
from collections import Counter
from dataclasses import dataclass
import logging
from .domain import Animal, Category, ValidationError
from .repository import AnimalRepository, RepositoryError

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SearchResult:
    animals: tuple[Animal, ...]
    message: str
    failed: bool = False


class RescueService:
    def __init__(self, repository: AnimalRepository):
        self.repository = repository

    def search(self, choice):
        try:
            category = Category.parse(choice)
        except ValidationError as error:
            return SearchResult((), str(error), True)
        try:
            animals = tuple(self.repository.find(category))
        except RepositoryError:
            # Never log exception text: driver errors can contain hosts or credentials.
            logger.warning('animal_search_failed category=%s', category.name)
            return SearchResult((), 'Unable to load animals. Check the data source and select Retry.', True)
        if not animals:
            return SearchResult((), 'No animals match this rescue category.')
        return SearchResult(animals, f'{len(animals)} animals loaded. Select a row to show its location.')


def selected_animal(animals, selected_ids):
    if not isinstance(selected_ids, list) or len(selected_ids) != 1:
        return None
    selected_id = selected_ids[0]
    return next((a for a in animals if a.record_id == selected_id), None)


def breed_counts(animals):
    counts = Counter(a.breed for a in animals)
    total = sum(counts.values())
    grouped = Counter()
    for breed, count in counts.items():
        grouped['Other' if count < total * .02 else breed] += count
    return dict(sorted(grouped.items()))
