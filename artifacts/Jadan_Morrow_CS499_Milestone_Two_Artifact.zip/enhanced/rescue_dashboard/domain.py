"""Typed records and the original rescue eligibility rules, independent of Dash."""
from dataclasses import dataclass
from enum import Enum
from math import isfinite
from typing import Mapping


class ValidationError(ValueError):
    """A user choice or record violates a documented application rule."""


class Category(str, Enum):
    RESET = 'Reset'
    WATER = 'Water Rescue'
    MOUNTAIN = 'Mountain or Wilderness Rescue'
    DISASTER = 'Disaster or Individual Tracking'

    @classmethod
    def parse(cls, value):
        try:
            return cls(value)
        except (ValueError, TypeError):
            raise ValidationError('Choose one of the listed rescue categories.') from None


@dataclass(frozen=True)
class RescueRule:
    breeds: tuple[str, ...]
    sex: str
    minimum_age: float
    maximum_age: float


RULES = {
    Category.WATER: RescueRule(('Labrador Retriever Mix', 'Chesapeake Bay Retriever',
                               'Newfoundland'), 'Intact Female', 26, 156),
    Category.MOUNTAIN: RescueRule(('German Shepherd', 'Alaskan Malamute',
                                  'Old English Sheepdog', 'Siberian Husky',
                                  'Rottweiler'), 'Intact Male', 26, 156),
    Category.DISASTER: RescueRule(('Doberman Pinscher', 'German Shepherd',
                                  'Golden Retriever', 'Bloodhound', 'Rottweiler'),
                                 'Intact Male', 20, 300),
}


def finite_number(value):
    # Do not turn missing values or booleans into a legitimate zero coordinate.
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return number if isfinite(number) else None


def text(value, default='Unknown'):
    return str(value).strip()[:200] if value is not None and str(value).strip() else default


@dataclass(frozen=True)
class Animal:
    record_id: str
    animal_id: str
    name: str
    animal_type: str
    breed: str
    sex: str
    age_weeks: float | None
    latitude: float | None
    longitude: float | None

    @classmethod
    def from_document(cls, data: Mapping):
        raw_id = data.get('_id')
        if raw_id is None:
            raw_id = data.get('id')
        if raw_id is None or not str(raw_id).strip():
            raise ValidationError('A record is missing its permanent record ID.')
        return cls(str(raw_id), text(data.get('animal_id')), text(data.get('name'), 'Unnamed'),
                   text(data.get('animal_type')), text(data.get('breed')),
                   text(data.get('sex_upon_outcome')),
                   finite_number(data.get('age_upon_outcome_in_weeks')),
                   finite_number(data.get('location_lat')), finite_number(data.get('location_long')))

    @property
    def coordinates(self):
        if self.latitude is None or self.longitude is None:
            return None
        if not (-90 <= self.latitude <= 90 and -180 <= self.longitude <= 180):
            return None
        return (self.latitude, self.longitude)

    def to_row(self):
        return {'id': self.record_id, 'animal_id': self.animal_id, 'name': self.name,
                'animal_type': self.animal_type, 'breed': self.breed,
                'sex_upon_outcome': self.sex, 'age_upon_outcome_in_weeks': self.age_weeks,
                'location_lat': self.latitude, 'location_long': self.longitude}


def eligible(animal: Animal, category: Category):
    if category == Category.RESET:
        return True
    rule = RULES[category]
    return (animal.animal_type == 'Dog' and animal.breed in rule.breeds
            and animal.sex == rule.sex and animal.age_weeks is not None
            and rule.minimum_age <= animal.age_weeks <= rule.maximum_age)


def rescue_query(category: Category):
    """Construct queries from an enum, never from a user-supplied dictionary."""
    if category == Category.RESET:
        return {}
    rule = RULES[category]
    return {'animal_type': 'Dog', 'breed': {'$in': list(rule.breeds)},
            'sex_upon_outcome': rule.sex,
            'age_upon_outcome_in_weeks': {'$gte': rule.minimum_age, '$lte': rule.maximum_age}}
