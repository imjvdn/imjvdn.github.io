"""Read-only repository interface and interchangeable data adapters."""
from typing import Protocol
import json
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from .domain import Animal, Category, ValidationError, eligible, rescue_query


class RepositoryError(RuntimeError):
    pass


class AnimalRepository(Protocol):
    def find(self, category: Category) -> list[Animal]: ...
    def close(self) -> None: ...


def normalize(documents):
    animals = [Animal.from_document(doc) for doc in documents]
    ids = [animal.record_id for animal in animals]
    if len(set(ids)) != len(ids):
        raise ValidationError('Record IDs must be unique.')
    return animals


class InMemoryRepository:
    def __init__(self, animals):
        self._animals = tuple(animals)

    @classmethod
    def from_file(cls, path):
        try:
            return cls(normalize(json.loads(path.read_text(encoding='utf-8'))))
        except (OSError, ValueError, TypeError, AttributeError):
            raise RepositoryError('Sample records could not be loaded.') from None

    def find(self, category):
        return [a for a in self._animals if eligible(a, category)]

    def close(self):
        pass


class MongoRepository:
    def __init__(self, collection, client=None):
        self._collection = collection
        self._client = client

    @classmethod
    def connect(cls, settings):
        try:
            client = MongoClient(settings.mongo_uri, serverSelectionTimeoutMS=2000,
                                 connectTimeoutMS=2000, socketTimeoutMS=2000)
            return cls(client[settings.database][settings.collection], client)
        except (PyMongoError, ValueError, TypeError):
            raise RepositoryError('Database configuration could not be used.') from None

    def find(self, category):
        # Milestone Two preserves full result loading. Server-side paging is future work.
        projection = {key: 1 for key in ('_id', 'animal_id', 'name', 'animal_type', 'breed',
                      'sex_upon_outcome', 'age_upon_outcome_in_weeks', 'location_lat', 'location_long')}
        try:
            with self._collection.find(rescue_query(category), projection) as cursor:
                return normalize(cursor)
        except (PyMongoError, ValidationError, TypeError, AttributeError):
            raise RepositoryError('Database records could not be loaded.') from None

    def close(self):
        if self._client is not None:
            self._client.close()


class UnavailableRepository:
    """Keeps the interface available when local sample configuration is invalid."""
    def find(self, category):
        raise RepositoryError('Data source unavailable.')

    def close(self):
        pass
