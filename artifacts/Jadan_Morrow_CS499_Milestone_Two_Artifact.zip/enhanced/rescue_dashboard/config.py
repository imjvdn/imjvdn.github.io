"""Runtime configuration. No stored credentials and no debug-by-default server."""
from dataclasses import dataclass, field
from pathlib import Path
import os
from .domain import ValidationError


@dataclass(frozen=True)
class Settings:
    source: str = 'sample'
    mongo_uri: str = field(default='', repr=False)
    database: str = 'aac'
    collection: str = 'animals'
    sample_path: Path = Path(__file__).resolve().parents[1] / 'data' / 'sample_animals.json'
    host: str = '127.0.0.1'
    port: int = 8050
    debug: bool = False

    @classmethod
    def from_environment(cls, env=None):
        env = os.environ if env is None else env
        source = env.get('RESCUE_DATA_SOURCE', 'sample')
        if source not in ('sample', 'mongo'):
            raise ValidationError('RESCUE_DATA_SOURCE must be sample or mongo.')
        uri = env.get('MONGODB_URI', '')
        if source == 'mongo' and not uri.startswith(('mongodb://', 'mongodb+srv://')):
            raise ValidationError('Set MONGODB_URI to a MongoDB connection URI.')
        try:
            port = int(env.get('RESCUE_PORT', '8050'))
        except (ValueError, TypeError):
            raise ValidationError('RESCUE_PORT must be an integer from 1 to 65535.') from None
        if not 1 <= port <= 65535:
            raise ValidationError('RESCUE_PORT must be an integer from 1 to 65535.')
        debug = env.get('RESCUE_DEBUG', 'false').lower()
        if debug not in ('true', 'false'):
            raise ValidationError('RESCUE_DEBUG must be true or false.')
        return cls(source=source, mongo_uri=uri, database=env.get('MONGODB_DATABASE', 'aac'),
                   collection=env.get('MONGODB_COLLECTION', 'animals'), port=port,
                   debug=debug == 'true')
