"""Standalone Dash UI. Callbacks translate between the UI and application service."""
import atexit
import logging
from pathlib import Path
from dash import Dash, Input, Output, State, dcc, html, dash_table
import dash_leaflet as dl
from .config import Settings
from .domain import Animal, Category, ValidationError
from .repository import InMemoryRepository, MongoRepository, RepositoryError, UnavailableRepository
from .service import RescueService, breed_counts, selected_animal


def create_app(settings=None, repository=None):
    settings = settings or Settings.from_environment()
    if repository is None:
        try:
            repository = (MongoRepository.connect(settings) if settings.source == 'mongo'
                          else InMemoryRepository.from_file(settings.sample_path))
        except RepositoryError:
            logging.getLogger(__name__).warning('data_source_initialization_failed')
            repository = UnavailableRepository()
    service = RescueService(repository)
    atexit.register(repository.close)
    app = Dash(__name__, assets_folder=str(Path(__file__).resolve().parents[1] / 'assets'))
    app.title = 'Grazioso Salvare Rescue Dashboard'
    columns = [('Animal ID', 'animal_id'), ('Name', 'name'), ('Type', 'animal_type'),
               ('Breed', 'breed'), ('Sex', 'sex_upon_outcome'),
               ('Age in weeks', 'age_upon_outcome_in_weeks')]
    app.layout = html.Main([
        html.Header([html.Img(src='/assets/logo.png', alt='Grazioso Salvare logo'),
                     html.Div([html.H1('Grazioso Salvare'), html.P('Animal rescue dashboard')])]),
        html.P('Sample mode — fictional records for demonstration and testing.'
               if settings.source == 'sample' else 'MongoDB mode — database-backed records.',
               className='source-label'),
        html.Section([
            html.H2('Find rescue candidates'),
            dcc.RadioItems(id='category', options=[{'label': 'Reset (Show All)' if c == Category.RESET
                          else c.value, 'value': c.value} for c in Category], value=Category.RESET.value,
                          labelStyle={'display': 'inline-block', 'marginRight': '1.5rem'}),
            html.Button('Retry / Refresh', id='retry', n_clicks=0),
            dcc.Loading(html.P(id='status', role='status', **{'aria-live': 'polite'})),
            html.P('Filter or sort the table to explore results. Changing rescue category or refreshing clears the selection.'),
            dash_table.DataTable(id='animals', columns=[{'name': name, 'id': key, 'selectable': True}
                 for name, key in columns], data=[], page_action='native', page_size=10,
                 sort_action='native', filter_action='native', row_selectable='single',
                 selected_rows=[], selected_row_ids=[], column_selectable='multi', selected_columns=[],
                 style_table={'overflowX': 'auto'}, style_cell={'textAlign': 'left', 'padding': '12px',
                 'fontFamily': 'Arial', 'whiteSpace': 'normal', 'height': 'auto'},
                 style_header={'backgroundColor': '#e7eef5', 'fontWeight': 'bold'}),
        ]),
        html.Section([html.Div(id='chart', className='panel'),
                      html.Div(id='map', className='panel')], className='views'),
        html.Footer('Jadan Morrow | CS 499 | Software Design and Engineering')
    ])

    @app.callback(Output('animals', 'data'), Output('status', 'children'),
                  Output('animals', 'selected_rows'), Output('animals', 'selected_row_ids'),
                  Output('animals', 'page_current'),
                  Input('category', 'value'), Input('retry', 'n_clicks'))
    def load_animals(category, _retry):
        result = service.search(category)
        return [animal.to_row() for animal in result.animals], result.message, [], [], 0

    @app.callback(Output('chart', 'children'), Output('map', 'children'),
                  Input('animals', 'derived_virtual_data'), Input('animals', 'selected_row_ids'),
                  Input('animals', 'data'))
    def update_views(view_rows, selected_ids, source_rows):
        rows = source_rows if view_rows is None else view_rows
        try:
            animals = [Animal.from_document(row) for row in (rows or [])]
        except (ValidationError, TypeError, AttributeError):
            return html.P('Record data is invalid. Select Retry.'), html.P('Location unavailable.')
        if not animals:
            return html.P('No animals to chart.'), html.P('No animal location to display.')
        counts = breed_counts(animals)
        chart = dcc.Graph(figure={'data': [{'type': 'pie', 'labels': list(counts),
                         'values': list(counts.values()), 'hole': .3}],
                         'layout': {'title': {'text': 'Breeds in all table-filtered results'},
                                    'margin': {'t': 50, 'b': 20, 'l': 20, 'r': 20}}})
        animal = selected_animal(animals, selected_ids)
        if animal is None:
            return chart, html.P('Select an animal in the current results to view its location.')
        if animal.coordinates is None:
            return chart, html.P(f'Location unavailable for {animal.name}: coordinates are missing or invalid.')
        location = list(animal.coordinates)
        map_view = html.Div([html.H2(f'Location for {animal.name}'),
                    dl.Map(center=location, zoom=10, style={'height': '370px', 'width': '100%'},
                           children=[dl.TileLayer(attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'), dl.Marker(position=location,
                             children=[dl.Tooltip(animal.breed), dl.Popup(animal.name)])]),
                    html.P('Map tiles require internet access. Location is the recorded shelter location.')])
        return chart, map_view

    allowed_columns = {key for _, key in columns}

    @app.callback(Output('animals', 'style_data_conditional'), Input('animals', 'selected_columns'))
    def highlight_columns(columns):
        return [{'if': {'row_index': 'odd'}, 'backgroundColor': '#f5f8fc'}] + [
            {'if': {'column_id': key}, 'backgroundColor': '#d2f3ff'}
            for key in (columns or []) if key in allowed_columns]

    # Expose the application boundary for direct callback tests without a running browser.
    app.rescue_callbacks = {'load': load_animals, 'views': update_views, 'highlight': highlight_columns}
    app.rescue_repository = repository
    return app


def main():
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(name)s %(message)s')
    # The Mongo driver can emit topology details at DEBUG; keep it quiet.
    logging.getLogger('pymongo').setLevel(logging.WARNING)
    try:
        settings = Settings.from_environment()
    except ValidationError as error:
        raise SystemExit(str(error)) from None
    app = create_app(settings)
    try:
        app.run(host=settings.host, port=settings.port, debug=settings.debug)
    finally:
        app.rescue_repository.close()


if __name__ == '__main__':
    main()
